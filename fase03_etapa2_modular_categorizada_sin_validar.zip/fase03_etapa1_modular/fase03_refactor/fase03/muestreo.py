"""
muestreo.py
===========
Aísla la decisión de QUÉ usuarios entran al pipeline, separada de QUÉ
se hace una vez que ya fueron elegidos (extracción de historial,
features, etc.).

DÓNDE SE APLICA OCP Y DIP (justificación real, no nominal)
-----------------------------------------------------------
- OCP: agregar una nueva estrategia de muestreo (ej. estratificada por
  presencia de Account Takeover) NO requiere modificar PipelineFase03
  ni ninguna otra clase del pipeline — solo se agrega una clase nueva
  que implementa EstrategiaMuestreo y se inyecta en su lugar.
- DIP: PipelineFase03 depende de la abstracción EstrategiaMuestreo,
  inyectada por constructor. Nunca instancia una estrategia concreta
  internamente (ver pipeline.py).

ETAPA 1 (este archivo, tal como se entrega hoy)
-------------------------------------------------
Solo se implementa MuestreoAleatorioSimple, que reproduce EXACTAMENTE
la lógica de seleccionar_usuarios() en fase03_pipeline_v4.py — cero
cambios metodológicos.

MuestreoEstratificadoPorTarget queda con la interfaz definida pero SIN
IMPLEMENTAR (levanta NotImplementedError), a la espera del diagnóstico
pendiente sobre los usuarios con Account Takeover=True (Etapa 2 del
proyecto). No se debe activar ni se debe especular su lógica interna
todavía.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from collections import Counter

import numpy as np


@dataclass
class ResultadoMuestreo:
    """Resultado de una estrategia de muestreo.

    'origen' es metadato de trazabilidad académica: de dónde vino cada
    usuario ('aleatorio', o en el futuro 'positivo_forzado'). Esto es
    lo que permite documentar honestamente, en la Etapa 2, que la
    prevalencia de la muestra final no representa la prevalencia real
    del RBA completo.

    En la Etapa 1, con MuestreoAleatorioSimple como única estrategia,
    todos los usuarios tienen origen='aleatorio'.
    """
    usuarios: list
    origen: dict = field(default_factory=dict)


class EstrategiaMuestreo(ABC):
    """Contrato: decide QUÉ usuarios entran al pipeline. Nunca decide
    QUÉ VALOR toma una feature — esa frontera es la que separa
    "usar el target para seleccionar la muestra" (válido, si se
    documenta) de "usar el target para construir features" (target
    leakage, prohibido en todos los casos)."""

    @abstractmethod
    def seleccionar(self, contador_usuarios: Counter) -> ResultadoMuestreo:
        ...


class MuestreoAleatorioSimple(EstrategiaMuestreo):
    """Selección ALEATORIA, REPRODUCIBLE, SIN REEMPLAZO de N_USUARIOS
    entre los usuarios con >= MIN_EVENTOS_USUARIO eventos.

    Lógica IDÉNTICA a seleccionar_usuarios() en fase03_pipeline_v4.py.
    Cero cambios metodológicos en esta etapa — es la estrategia que ya
    produjo el resultado real de 2.000 usuarios / 54.742 eventos /
    0 positivos, documentado y explicado en la sesión anterior.
    """

    def __init__(self, config):
        self.config = config

    def seleccionar(self, contador_usuarios):
        config = self.config
        print("=" * 60)
        print("[3/8] Seleccionando usuarios (muestreo aleatorio simple)...")
        print("=" * 60)

        poblacion_elegible = [
            uid for uid, freq in contador_usuarios.items()
            if freq >= config.MIN_EVENTOS_USUARIO
        ]
        poblacion_elegible.sort()

        print(f"  Usuarios con >= {config.MIN_EVENTOS_USUARIO} eventos: "
              f"{len(poblacion_elegible):,}")

        if len(poblacion_elegible) < config.N_USUARIOS:
            raise ValueError(
                "La población elegible es menor que N_USUARIOS. "
                "Revisa MIN_EVENTOS_USUARIO o el archivo de origen."
            )

        rng = np.random.default_rng(config.RANDOM_STATE)
        usuarios_seleccionados = rng.choice(
            poblacion_elegible, size=config.N_USUARIOS, replace=False
        )
        usuarios_seleccionados = sorted(int(u) for u in usuarios_seleccionados)

        if len(set(usuarios_seleccionados)) != config.N_USUARIOS:
            raise RuntimeError(
                "ERROR CRÍTICO: la selección de usuarios no produjo exactamente "
                f"{config.N_USUARIOS} usuarios únicos. Selección abortada."
            )
        for uid in usuarios_seleccionados:
            if contador_usuarios[uid] < config.MIN_EVENTOS_USUARIO:
                raise RuntimeError(
                    f"ERROR CRÍTICO: el usuario {uid} fue seleccionado pero no "
                    f"cumple MIN_EVENTOS_USUARIO. Selección abortada."
                )

        print(f"  Usuarios seleccionados: {len(usuarios_seleccionados):,} "
              f"(RANDOM_STATE={config.RANDOM_STATE})")
        print("  [OK] Verificado: exactamente N_USUARIOS únicos, todos con "
              "el mínimo de eventos requerido.\n")

        origen = {uid: "aleatorio" for uid in usuarios_seleccionados}
        return ResultadoMuestreo(usuarios=usuarios_seleccionados, origen=origen)


class MuestreoEstratificadoPorTarget(EstrategiaMuestreo):
    """PENDIENTE DE IMPLEMENTACIÓN — Etapa 2 del proyecto.

    Objetivo futuro (NO implementado todavía): garantizar que la
    muestra de N_USUARIOS incluya deliberadamente a los usuarios con
    >=1 evento 'Is Account Takeover'=True (diseño caso-control),
    documentando el sesgo de prevalencia que esto introduce respecto
    al RBA completo.

    Esta clase existe HOY únicamente para fijar el contrato de la
    interfaz (mismo método seleccionar(), misma firma de retorno
    ResultadoMuestreo) y así demostrar que PipelineFase03 no necesitará
    cambios cuando se implemente — solo se inyectará esta clase en vez
    de MuestreoAleatorioSimple.

    Precondición pendiente antes de escribir su lógica interna:
    ejecutar el diagnóstico de cuántos de los usuarios con Account
    Takeover=True cumplen MIN_EVENTOS_USUARIO >= 15, y cómo se
    distribuyen los eventos positivos entre ellos (Etapa 2).

    Nota metodológica (para cuando se implemente): usar el target
    aquí NO constituye target leakage — decide qué FILAS/USUARIOS
    entran al dataset, nunca qué VALOR toma una feature. Ver
    docs/FASE_03_INFORME_TECNICO.md, sección "Prevención de target
    leakage", para la justificación completa y la distinción formal
    entre ambos usos del target.
    """

    def __init__(self, config):
        self.config = config

    def seleccionar(self, contador_usuarios):
        raise NotImplementedError(
            "MuestreoEstratificadoPorTarget aún no está implementado. "
            "Pendiente del diagnóstico de la Etapa 2: cuántos usuarios con "
            "Is Account Takeover=True cumplen MIN_EVENTOS_USUARIO>=15, y "
            "cómo se distribuyen sus eventos positivos. "
            "Usa MuestreoAleatorioSimple mientras tanto."
        )
