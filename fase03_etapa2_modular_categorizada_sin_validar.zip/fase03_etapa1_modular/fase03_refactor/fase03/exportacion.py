"""
exportacion.py
==============
Selección de columnas finales + escritura de dataset_final_modelo.csv.
Se mantiene como FUNCIÓN, mismo criterio que validacion.py/features.py.
"""


def exportar_dataset_final(df, config):
    """Exporta dataset_final_modelo.csv.
    Garantiza que 'Is Account Takeover' quede como ÚLTIMA columna,
    conservando todas las variables categorizadas.
    """
    if "Is Account Takeover" in df.columns:
        target = df.pop("Is Account Takeover")
        df["Is Account Takeover"] = target

    df.to_csv(config.OUT_DATASET_FINAL, index=False)
    return df
