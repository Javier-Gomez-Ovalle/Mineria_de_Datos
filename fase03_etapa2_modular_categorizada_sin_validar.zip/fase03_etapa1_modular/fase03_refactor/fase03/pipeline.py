"""
pipeline.py
===========
Orquestador de las 8 etapas de la Fase 03.

DIP EN ACCIÓN
-------------
PipelineFase03 recibe la estrategia de muestreo POR CONSTRUCTOR
(inyección de dependencia) — nunca instancia una estrategia concreta
internamente. Esto permite sustituir MuestreoAleatorioSimple por
MuestreoEstratificadoPorTarget (Etapa 2) sin modificar ni una línea
de esta clase.

REGLA DE MEMORIA
-----------------
self solo guarda config y la estrategia de muestreo (ambos livianos).
Ningún DataFrame grande ni Counter se guarda como atributo de
instancia — todos son variables locales de ejecutar(), liberadas
explícitamente con del + gc.collect() en los mismos puntos donde ya
se liberaban en fase03_pipeline_v4.py.

BARRERA ESTRUCTURAL CONTRA TARGET LEAKAGE
-------------------------------------------
'Is Account Takeover' se retira FÍSICAMENTE del DataFrame
(df.pop(...)) inmediatamente después de la resolución IP y ANTES de
que cualquier función de features.py reciba el DataFrame. Se
reincorpora únicamente después de que todas las features ya fueron
construidas, justo antes de validar/exportar. Mientras la columna no
existe en el DataFrame, es físicamente imposible que una función de
features la lea — incluso por un descuido futuro de quien edite
features.py, ya que un KeyError sería inmediato si lo intentara.
"""
import gc
import pandas as pd
from .rba_reader import AnalizadorRBA
from .empleados import GeneradorEmpleados
from .ip_resolver import ResolutorIPinfo
from .features import (
    crear_features_temporales,
    crear_feature_impossible_travel,
    crear_feature_turnos,
    crear_features_negocio,
)
from .validacion import validar_calidad_bloqueante
from .diagnostico import generar_metricas_diagnosticas, imprimir_checklist_final
from .exportacion import exportar_dataset_final


class PipelineFase03:
    def __init__(self, config, estrategia_muestreo):
        self.config = config
        self.estrategia_muestreo = estrategia_muestreo

    def ejecutar(self):
        config = self.config

        # --- [1-2/8] Análisis del RBA completo por chunks ---
        analizador = AnalizadorRBA(config)
        contador_usuarios, diagnostico_global = analizador.primera_pasada()

        # --- [3/8] Selección de usuarios (estrategia inyectada) ---
        resultado_muestreo = self.estrategia_muestreo.seleccionar(contador_usuarios)
        usuarios_seleccionados = resultado_muestreo.usuarios
        del contador_usuarios
        gc.collect()

        # --- [4/8] Extracción del historial completo ---
        df_logs, diagnostico_subconjunto = analizador.segunda_pasada(usuarios_seleccionados)

        # --- [5/8] Maestro sintético de empleados ---
        generador_empleados = GeneradorEmpleados(config)
        df_empleados = generador_empleados.generar(usuarios_seleccionados)

        df_integrado = df_logs.merge(df_empleados, on="User ID", how="inner")
        del df_logs, df_empleados
        gc.collect()

        # --- [6/8] Resolución IP (incluye fix de dtype de merge_asof) ---
        resolutor_ip = ResolutorIPinfo(config)
        df_integrado, diagnostico_resolucion = resolutor_ip.resolver(df_integrado)

        # --- BARRERA ESTRUCTURAL ANTI-LEAKAGE ---
        if "Is Account Takeover" not in df_integrado.columns:
            raise RuntimeError(
                "ERROR CRÍTICO: 'Is Account Takeover' no está presente antes "
                "de retirarla para la construcción de features. Esto no "
                "debería ocurrir — revisa la extracción del RBA."
            )
        serie_target = df_integrado.pop("Is Account Takeover")

        # --- [7/8] Ingeniería de características (target físicamente ausente) ---
        df_integrado, n_login_desconocidos = crear_features_temporales(df_integrado, config)
        df_integrado, diagnostico_centroides = crear_feature_impossible_travel(df_integrado, config)
        df_integrado = crear_feature_turnos(df_integrado)
        df_integrado = crear_features_negocio(df_integrado)

        # --- Reincorporación del target (solo ahora) ---
        df_integrado["Is Account Takeover"] = serie_target
        del serie_target

        # --- [8/8] Validación bloqueante + exportación + diagnóstico ---
        validar_calidad_bloqueante(df_integrado, usuarios_seleccionados, config)

        # =========================================================================
        # CATEGORIZACIÓN DE VARIABLES (FORMAT DATA - CRISP-DM)
        # =========================================================================
        columnas_a_categorizar = [
            "Device Type", "ip_country_code", "Rol_Hospitalario", 
            "Pais_Residencia", "Ciudad_Base", "Turno_Asignado", "Estado_Cuenta"
        ]
        categoricas_presentes = [c for c in columnas_a_categorizar if c in df_integrado.columns]
        
        # Genera las variables dummy (0 y 1) sin eliminar registros
        df_integrado = pd.get_dummies(
            df_integrado, 
            columns=categoricas_presentes, 
            drop_first=False, 
            dtype=int
        )
        # =========================================================================

        df_final = exportar_dataset_final(df_integrado, config)

        metricas = generar_metricas_diagnosticas(
            df_integrado, usuarios_seleccionados, diagnostico_global,
            diagnostico_subconjunto, diagnostico_resolucion,
            diagnostico_centroides, n_login_desconocidos, config,
        )

        imprimir_checklist_final(df_final, metricas, config)

        return df_final
