"""
test_fase03.py
==============
Suite de regresión de la Etapa 1 (refactor arquitectónico sin cambios
metodológicos). Cuatro capas, según lo acordado:

  CAPA A — equivalencia end-to-end (modular vs. monolito v4) sobre
           datos REALES (rba_2000_users.csv + catálogo IPinfo).
           Requiere archivos que solo existen en el Colab de Javier;
           se omite automáticamente si no están presentes (ver
           conftest.py), en vez de fingir que pasó.
  CAPA B — reproducibilidad de empleados.csv (mismos seeds -> mismo
           resultado, y equivalencia contra el monolito cuando hay
           fixture real).
  CAPA C — casos límite sintéticos (ISO2, centroides, country_mismatch,
           has_previous_login, edge case de un solo grupo en el
           rolling, fix de dtype de merge_asof).
  CAPA D — prueba de no-leakage: barajar 'Is Account Takeover' no debe
           cambiar ninguna feature calculada.

Además: un smoke test end-to-end con datos 100% sintéticos (no
requiere ningún archivo externo), que prueba que PipelineFase03 corre
de principio a fin sin errores.

Cuando una comparación falla, se usa pd.testing.assert_frame_equal con
check_exact=True, que reporta explícitamente qué columna y qué valores
difieren — nunca un booleano mudo de .equals().
"""
import importlib.util
import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fase03.config import ConfiguracionPipeline
from fase03.muestreo import MuestreoAleatorioSimple
from fase03.empleados import GeneradorEmpleados
from fase03.ip_resolver import ResolutorIPinfo
from fase03.features import (
    calcular_rolling_retrospectivo,
    crear_features_temporales,
    crear_feature_impossible_travel,
    crear_feature_turnos,
    crear_features_negocio,
)
from fase03.pipeline import PipelineFase03

from .conftest import requiere_fixture_real, ruta_fixture_rba_2000, ruta_fixture_ipinfo


def _cargar_monolito_v4():
    """Carga tests/legacy/fase03_pipeline_v4.py como módulo importable,
    para comparar su salida contra la arquitectura modular."""
    ruta = os.path.join(os.path.dirname(__file__), "legacy", "fase03_pipeline_v4.py")
    spec = importlib.util.spec_from_file_location("fase03_pipeline_v4_legacy", ruta)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


# ============================================================================
# CAPA A — Equivalencia end-to-end contra el pipeline monolítico (datos reales)
# ============================================================================

@requiere_fixture_real
def test_capa_a_equivalencia_end_to_end_contra_monolito(tmp_path):
    """Corre el monolito v4 y la arquitectura modular a partir del
    MISMO rba_2000_users.csv real, con el mismo config, y compara el
    dataset_final_modelo.csv resultante columna por columna."""
    legacy = _cargar_monolito_v4()

    df_2000 = pd.read_csv(ruta_fixture_rba_2000())
    usuarios_seleccionados = sorted(df_2000["User ID"].unique().tolist())

    # --- Config legacy (dict) ---
    config_legacy = legacy.configurar_entorno()
    config_legacy["IPINFO_PATH"] = ruta_fixture_ipinfo()
    config_legacy["N_USUARIOS"] = len(usuarios_seleccionados)
    config_legacy["OUT_EMPLEADOS"] = str(tmp_path / "empleados_legacy.csv")
    config_legacy["OUT_DATASET_FINAL"] = str(tmp_path / "dataset_legacy.csv")

    df_emp_legacy = legacy.generar_empleados(usuarios_seleccionados, config_legacy)
    df_int_legacy = df_2000.merge(df_emp_legacy, on="User ID", how="inner")
    df_int_legacy, _ = legacy.resolver_ips(df_int_legacy, config_legacy)
    df_int_legacy, _ = legacy.crear_features_temporales(df_int_legacy, config_legacy)
    df_int_legacy, _ = legacy.crear_feature_impossible_travel(df_int_legacy, config_legacy)
    df_int_legacy = legacy.crear_feature_turnos(df_int_legacy)
    df_int_legacy = legacy.crear_features_negocio(df_int_legacy)
    df_final_legacy = legacy.exportar_dataset_final(df_int_legacy, config_legacy)

    # --- Config modular (dataclass) ---
    config_modular = ConfiguracionPipeline(
        IPINFO_PATH=ruta_fixture_ipinfo(),
        N_USUARIOS=len(usuarios_seleccionados),
        OUT_EMPLEADOS=str(tmp_path / "empleados_modular.csv"),
        OUT_DATASET_FINAL=str(tmp_path / "dataset_modular.csv"),
    )

    df_emp_modular = GeneradorEmpleados(config_modular).generar(usuarios_seleccionados)
    df_int_modular = df_2000.merge(df_emp_modular, on="User ID", how="inner")
    df_int_modular, _ = ResolutorIPinfo(config_modular).resolver(df_int_modular)
    serie_target = df_int_modular.pop("Is Account Takeover")
    df_int_modular, _ = crear_features_temporales(df_int_modular, config_modular)
    df_int_modular, _ = crear_feature_impossible_travel(df_int_modular, config_modular)
    df_int_modular = crear_feature_turnos(df_int_modular)
    df_int_modular = crear_features_negocio(df_int_modular)
    df_int_modular["Is Account Takeover"] = serie_target
    from fase03.exportacion import exportar_dataset_final
    df_final_modular = exportar_dataset_final(df_int_modular, config_modular)

    pd.testing.assert_frame_equal(
        df_final_legacy.reset_index(drop=True),
        df_final_modular.reset_index(drop=True),
        check_exact=True,
        check_dtype=True,
    )


# ============================================================================
# CAPA B — Reproducibilidad de empleados.csv
# ============================================================================

def test_capa_b_empleados_reproducible_mismos_seeds():
    """Mismos RANDOM_STATE/FAKER_SEED + mismos usuarios -> mismo
    empleados.csv, byte a byte (columna a columna)."""
    config = ConfiguracionPipeline(N_USUARIOS=10)
    usuarios = list(range(1, 11))

    config.OUT_EMPLEADOS = "/tmp/empleados_run1.csv"
    df1 = GeneradorEmpleados(config).generar(usuarios)

    config.OUT_EMPLEADOS = "/tmp/empleados_run2.csv"
    df2 = GeneradorEmpleados(config).generar(usuarios)

    pd.testing.assert_frame_equal(df1, df2, check_exact=True)


@requiere_fixture_real
def test_capa_b_empleados_equivalente_a_monolito(tmp_path):
    """empleados.csv generado por la clase modular debe ser idéntico
    al generado por generar_empleados() del monolito, con el mismo
    config y la misma lista de usuarios reales."""
    legacy = _cargar_monolito_v4()

    df_2000 = pd.read_csv(ruta_fixture_rba_2000())
    usuarios_seleccionados = sorted(df_2000["User ID"].unique().tolist())

    config_legacy = legacy.configurar_entorno()
    config_legacy["N_USUARIOS"] = len(usuarios_seleccionados)
    config_legacy["OUT_EMPLEADOS"] = str(tmp_path / "empleados_legacy.csv")
    df_emp_legacy = legacy.generar_empleados(usuarios_seleccionados, config_legacy)

    config_modular = ConfiguracionPipeline(
        N_USUARIOS=len(usuarios_seleccionados),
        OUT_EMPLEADOS=str(tmp_path / "empleados_modular.csv"),
    )
    df_emp_modular = GeneradorEmpleados(config_modular).generar(usuarios_seleccionados)

    pd.testing.assert_frame_equal(
        df_emp_legacy.reset_index(drop=True),
        df_emp_modular.reset_index(drop=True),
        check_exact=True,
    )


# ============================================================================
# CAPA C — Casos límite sintéticos
# ============================================================================

def test_capa_c_pais_residencia_es_iso2():
    config = ConfiguracionPipeline(N_USUARIOS=5, OUT_EMPLEADOS="/tmp/empleados_c1.csv")
    df_emp = GeneradorEmpleados(config).generar([1, 2, 3, 4, 5])
    assert set(df_emp["Pais_Residencia"].unique()).issubset(config.ISO2_RECONOCIDOS)


def test_capa_c_centroides_usan_iso2_no_nombres_espanol():
    from fase03.config import CENTROIDES_GEOGRAFICOS
    assert "CO" in CENTROIDES_GEOGRAFICOS
    assert "Colombia" not in CENTROIDES_GEOGRAFICOS


def test_capa_c_country_mismatch_iso2_vs_iso2_y_nan_cuando_falta_info():
    df = pd.DataFrame({
        "Pais_Residencia": ["CO", "ES", "MX", None],
        "ip_country_code": ["CO", "US", "MX", "US"],
        "Estado_Cuenta": ["Activo", "Activo", "Inactivo", "Activo"],
        "login_exitoso_normalizado": [True, True, True, True],
    })
    df = crear_features_negocio(df)
    assert df.loc[0, "country_mismatch"] == 0
    assert df.loc[1, "country_mismatch"] == 1
    assert df.loc[2, "country_mismatch"] == 0
    assert pd.isna(df.loc[3, "country_mismatch"])


def test_capa_c_has_previous_login_y_nan_forzado_en_impossible_travel():
    config = ConfiguracionPipeline()
    df = pd.DataFrame({
        "User ID": [1, 1, 1],
        "IP Address": ["1.1.1.1", "1.1.1.2", "1.1.1.3"],
        "Login Timestamp": [1580000000, 1580000900, 1580100000],
        "Login Successful": [True, False, True],
        "Country": ["CO", "CO", "US"],
    })
    df, _ = crear_features_temporales(df, config)
    assert df.loc[0, "has_previous_login"] == 0
    assert df.loc[1, "has_previous_login"] == 1
    assert df.loc[2, "has_previous_login"] == 1

    df, _ = crear_feature_impossible_travel(df, config)
    assert pd.isna(df.loc[0, "distance_previous_km"])
    assert pd.isna(df.loc[0, "required_speed_kmh"])
    # CO -> US SÍ debe resolver distancia (centroides ISO2 alineados con
    # el formato nativo de RBA "Country"; antes, con nombres en español,
    # este lookup fallaba silenciosamente).
    assert not pd.isna(df.loc[2, "distance_previous_km"])


def test_capa_c_rolling_retrospectivo_con_un_solo_usuario():
    """Edge case de pandas >= 3.0: groupby().apply() puede devolver un
    DataFrame en vez de una Series concatenada cuando hay un único
    grupo. calcular_rolling_retrospectivo() debe ser robusto a esto."""
    df = pd.DataFrame({
        "User ID": [1, 1, 1],
        "Login Timestamp": pd.to_datetime([1580000000, 1580000900, 1580100000], unit="s"),
        "is_failed": [0, 1, 0],
    })
    resultado = calcular_rolling_retrospectivo(df, "is_failed", "15min")
    assert isinstance(resultado, pd.Series)
    assert pd.isna(resultado.iloc[0])
    assert resultado.iloc[1] == 0.0


def test_capa_c_merge_asof_dtype_fix_reproduce_escenario_real():
    """Reproduce el escenario exacto que causó el MergeError original:
    RBA con IPv6 mezclada (fuerza float64 en ip_int) vs. catálogo
    IPinfo 100% IPv4 (nace int64 nativamente)."""
    config = ConfiguracionPipeline(IPINFO_PATH="/tmp/ipinfo_mini_capa_c.csv")

    df_logs = pd.DataFrame({
        "IP Address": ["8.8.8.8", "1.1.1.1", "2001:db8::1", "9.9.9.9"],
    })
    from fase03.ip_utils import clasificar_ip
    clasif = df_logs["IP Address"].apply(clasificar_ip)
    df_logs["ip_int"] = clasif.apply(lambda t: t[0])
    df_logs["ip_version"] = clasif.apply(lambda t: t[1])
    assert df_logs["ip_int"].dtype == np.float64  # confirma que se reprodujo el escenario

    df_ipinfo_mini = pd.DataFrame({
        "start_ip": ["1.0.0.0", "8.0.0.0", "9.0.0.0"],
        "end_ip": ["1.255.255.255", "8.255.255.255", "9.255.255.255"],
        "country": ["US", "US", "US"],
        "country_name": ["United States", "United States", "United States"],
        "asn": ["AS1", "AS2", "AS3"],
        "as_name": ["A", "B", "C"],
        "as_domain": ["a.com", "b.com", "c.com"],
    })
    df_ipinfo_mini.to_csv(config.IPINFO_PATH, index=False)

    # No debe lanzar MergeError.
    df_resultado, diagnostico = ResolutorIPinfo(config).resolver(df_logs)
    assert diagnostico["ipv4_unicas_resueltas"] == 3


# ============================================================================
# CAPA D — Prueba de no-leakage
# ============================================================================

def _df_integrado_sintetico(n_usuarios=3, eventos_por_usuario=5, seed=0):
    rng = np.random.default_rng(seed)
    filas = []
    paises = ["CO", "US", "ES"]
    for uid in range(1, n_usuarios + 1):
        base_ts = 1580000000
        for i in range(eventos_por_usuario):
            filas.append({
                "User ID": uid,
                "IP Address": f"1.1.1.{uid}",
                "Login Timestamp": base_ts + i * 1000,
                "Login Successful": bool(rng.integers(0, 2)),
                "Country": paises[uid % len(paises)],
                "Pais_Residencia": paises[(uid + 1) % len(paises)],
                "ip_country_code": paises[uid % len(paises)],
                "Estado_Cuenta": "Activo" if uid % 2 == 0 else "Inactivo",
                "Turno_Asignado": "Diurno",
            })
    return pd.DataFrame(filas)


def _construir_todas_las_features(df, config):
    df, _ = crear_features_temporales(df, config)
    df, _ = crear_feature_impossible_travel(df, config)
    df = crear_feature_turnos(df)
    df = crear_features_negocio(df)
    return df


def test_capa_d_no_leakage_barajar_target_no_cambia_ninguna_feature():
    """Construye el mismo DataFrame base dos veces, cambiando
    ÚNICAMENTE los valores de 'Is Account Takeover' (barajados
    aleatoriamente), y confirma que TODAS las columnas de features
    calculadas son idénticas entre ambas corridas."""
    config = ConfiguracionPipeline()
    rng = np.random.default_rng(1)

    base = _df_integrado_sintetico()
    target_a = rng.integers(0, 2, size=len(base)).astype(bool)
    target_b = rng.permutation(target_a)  # mismos valores, orden barajado

    df_a = base.copy()
    df_a["Is Account Takeover"] = target_a
    df_b = base.copy()
    df_b["Is Account Takeover"] = target_b

    # Barrera real del pipeline: se retira ANTES de construir features.
    df_a.pop("Is Account Takeover")
    df_b.pop("Is Account Takeover")

    df_a = _construir_todas_las_features(df_a, config)
    df_b = _construir_todas_las_features(df_b, config)

    columnas_features = [
        "failed_attempts_15min", "failed_attempts_1h", "has_previous_login",
        "distance_previous_km", "required_speed_kmh", "impossible_travel",
        "is_outside_shift", "country_mismatch", "inactive_account_success",
    ]
    pd.testing.assert_frame_equal(
        df_a[columnas_features].reset_index(drop=True),
        df_b[columnas_features].reset_index(drop=True),
        check_exact=True,
    )


def test_capa_d_features_py_no_menciona_is_account_takeover():
    """Garantía estructural adicional: el código fuente de features.py
    no debe contener ninguna referencia textual a 'Is Account
    Takeover'. Si alguien la agregara por descuido, este test la
    detecta sin necesidad de ejecutar nada."""
    ruta_features = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), "fase03", "features.py"
    )
    contenido = open(ruta_features, encoding="utf-8").read()
    assert "Is Account Takeover" not in contenido


# ============================================================================
# SMOKE TEST — pipeline completo con datos 100% sintéticos (sin
# depender de ningún archivo externo). No es una de las 4 capas
# acordadas, mide únicamente que el cableado (imports, orquestación,
# inyección de dependencia) funciona de principio a fin.
# ============================================================================

def _generar_rba_sintetico(ruta, n_usuarios=8, eventos_por_usuario=16, seed=7):
    rng = np.random.default_rng(seed)
    filas = []
    ts_base = 1_580_000_000
    for uid in range(1, n_usuarios + 1):
        for i in range(eventos_por_usuario):
            filas.append({
                "User ID": uid,
                "IP Address": f"8.8.8.{(uid * 3 + i) % 255}",
                "Login Timestamp": ts_base + i * 900 + uid * 10,
                "Login Successful": bool(rng.integers(0, 2)),
                "Device Type": "Desktop",
                "Is Attack IP": False,
                "Is Account Takeover": bool(i == 0 and uid == 1),
                "Country": "CO" if uid % 2 == 0 else "US",
                "Region": "N/A",
                "City": "N/A",
                "ASN": "AS1",
                "Round-Trip Time [ms]": 50,
            })
    pd.DataFrame(filas).to_csv(ruta, index=False)


def _generar_ipinfo_sintetico(ruta):
    df = pd.DataFrame({
        "start_ip": ["8.8.8.0"],
        "end_ip": ["8.8.8.255"],
        "country": ["US"],
        "country_name": ["United States"],
        "asn": ["AS15169"],
        "as_name": ["Google"],
        "as_domain": ["google.com"],
    })
    df.to_csv(ruta, index=False)


def test_smoke_pipeline_completo_end_to_end_sintetico(tmp_path):
    rba_path = tmp_path / "rba_mini.csv"
    ipinfo_path = tmp_path / "ipinfo_mini.csv"
    _generar_rba_sintetico(str(rba_path))
    _generar_ipinfo_sintetico(str(ipinfo_path))

    config = ConfiguracionPipeline(
        RBA_PATH=str(rba_path),
        IPINFO_PATH=str(ipinfo_path),
        OUT_RBA_2000=str(tmp_path / "rba_seleccionados.csv"),
        OUT_EMPLEADOS=str(tmp_path / "empleados.csv"),
        OUT_DATASET_FINAL=str(tmp_path / "dataset_final_modelo.csv"),
        N_USUARIOS=5,
        MIN_EVENTOS_USUARIO=10,
        CHUNKSIZE_PASADA_1=1000,
        CHUNKSIZE_PASADA_2=1000,
    )
    estrategia = MuestreoAleatorioSimple(config)
    pipeline = PipelineFase03(config, estrategia)

    df_final = pipeline.ejecutar()

    assert len(df_final) > 0
    assert df_final["User ID"].nunique() == 5
    assert "Is Account Takeover" in df_final.columns
    assert "has_previous_login" in df_final.columns
    assert "country_mismatch" in df_final.columns
    assert os.path.exists(config.OUT_DATASET_FINAL)
