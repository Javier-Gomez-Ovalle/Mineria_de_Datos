"""
main.py — punto de entrada ejecutable de la Fase 03.

Equivalente al bloque `if __name__ == "__main__": main()` del script
monolítico fase03_pipeline_v4.py. En Google Colab: sube la carpeta
fase03/ junto a este archivo a /content/, ajusta las rutas en
ConfiguracionPipeline si es necesario, y ejecuta `%run main.py` o
`python main.py`.
"""
from fase03.config import ConfiguracionPipeline
from fase03.muestreo import MuestreoEstratificadoPorTarget  # <-- CAMBIADO
from fase03.pipeline import PipelineFase03


def main():
    config = ConfiguracionPipeline()
    # Usar muestreo estratificado/dirigido para incluir los usuarios con ataques ATO
    estrategia = MuestreoEstratificadoPorTarget(config)  # <-- CAMBIADO
    pipeline = PipelineFase03(config, estrategia)
    return pipeline.ejecutar()


if __name__ == "__main__":
    main()