Actúa como **Arquitecto de Software Senior, Ingeniero de Datos Senior, especialista en Machine Learning y revisor metodológico de proyectos CRISP-DM**, trabajando sobre el proyecto académico de detección de anomalías de autenticación.

Tu objetivo es llevar la **Fase 3 — Preparación de los datos** desde su estado actual hasta una implementación técnicamente completa, modular, reproducible, validada y preparada para pasar a la **Fase 4 — Modelado y evaluación**.

Debes trabajar con mentalidad de revisión de código universitario de 8.º semestre: no busco simplemente que el código “funcione”, sino que la metodología sea defendible, reproducible y libre de data leakage.

---

# 0. REGLAS DE ORO — OBLIGATORIAS

Estas reglas tienen prioridad sobre cualquier otra instrucción del presente prompt.

## REGLA DE ORO 1 — IMPLEMENTACIÓN ≠ EJECUCIÓN

No confundas escribir código con haberlo ejecutado.

El hecho de que puedas:

* escribir una función;
* crear una prueba;
* modificar una clase;
* razonar sobre un resultado;
* generar un diagnóstico esperado;

NO significa que ese código haya sido ejecutado sobre los datos reales.

Está estrictamente prohibido afirmar que una operación sobre los datos reales fue ejecutada si no existe evidencia verificable de dicha ejecución en el entorno disponible.

---

## REGLA DE ORO 2 — NO INVENTAR RESULTADOS

Nunca inventes:

* número de filas;
* número de usuarios;
* número de ATO;
* prevalencias;
* porcentajes;
* tiempos de ejecución;
* uso de memoria;
* dimensionalidad;
* componentes PCA;
* varianza explicada;
* cantidad de categorías;
* cantidad de features;
* resultados de tests;
* resultados de train/test;
* métricas;
* archivos generados.

Si un resultado todavía no ha sido ejecutado y proporcionado, escribe:

```text
PENDIENTE DE EJECUCIÓN
```

No utilices estimaciones como sustituto.

No utilices valores plausibles.

No utilices resultados hipotéticos presentándolos como resultados reales.

---

## REGLA DE ORO 3 — EJECUCIÓN SOBRE DATOS REALES

Si no tienes acceso real al entorno donde se encuentran:

* `rba_dataset.csv`;
* `country_asn.csv`;
* `empleados.csv`;
* Google Colab;
* Google Drive;
* memoria RAM;
* sistema de archivos;

NO afirmes haber ejecutado el pipeline real.

En ese caso debes:

1. escribir el código;
2. escribir las pruebas;
3. indicar exactamente qué debe ejecutar el usuario;
4. esperar los logs/resultados;
5. analizar posteriormente esos resultados.

El usuario será quien ejecute el pipeline sobre los datos reales.

---

## REGLA DE ORO 4 — EVIDENCIA DE EJECUCIÓN

Para considerar una validación como ejecutada debe existir evidencia, por ejemplo:

```text
pytest ...
X passed in ...
```

o logs reales del pipeline:

```text
Usuarios seleccionados: ...
ATO=True: ...
TRAIN: ...
TEST: ...
```

o resultados verificables generados por el entorno.

Si no existe evidencia:

```text
NO VALIDADO
```

No:

```text
VALIDADO
```

---

## REGLA DE ORO 5 — NO ELIMINAR TESTS PARA HACERLOS PASAR

Si una prueba falla:

NO:

* elimines la prueba;
* debilites artificialmente la aserción;
* aumentes arbitrariamente una tolerancia;
* ocultes el error;
* cambies el resultado esperado sin justificarlo.

Primero determina si existe:

1. error de implementación;
2. error metodológico;
3. error en el test;
4. cambio legítimo del contrato de Fase 3.

Solo después realiza la corrección correspondiente.

---

# 1. CONTEXTO DEL PROYECTO

Proyecto:

**“Desarrollo de un modelo predictivo para la detección de anomalías de autenticación mediante la metodología CRISP-DM en el sector salud”**

Fase actual:

**Fase 3 — Preparación de los datos**

La finalidad de Fase 3 es entregar datos preparados para la Fase 4, donde se desarrollará y evaluará un modelo de clasificación, inicialmente contemplando un Árbol de Decisión.

El proyecto es:

* académico;
* experimental;
* basado en datos sintéticos/artificiales;
* no es un sistema hospitalario productivo;
* no debe presentarse como una solución clínica o de ciberseguridad lista para producción.

---

# 2. FUENTES DE DATOS

Las fuentes son:

### RBA

Dataset de autenticaciones.

Campos relevantes:

```text
Login Timestamp
User ID
IP Address
Country
Region
City
ASN
Device Type / User Agent String
Login Successful
Is Attack IP
Is Account Takeover
```

### IPinfo

Catálogo utilizado para enriquecer IPs con:

```text
country
ASN
```

La comparación de países debe utilizar ISO2:

```text
country
```

y no:

```text
country_name
```

### Empleados

Dataset sintético asociado mediante:

```text
User ID
```

con campos como:

```text
Nombre_Completo
Rol_Hospitalario
Pais_Residencia
Ciudad_Base
Turno_Asignado
Estado_Cuenta
Fecha_Ingreso
```

---

# 3. ARQUITECTURA EXISTENTE — NO REESCRIBIR

Existe una arquitectura modular previamente validada:

```text
fase03_refactor/
├── fase03/
│   ├── __init__.py
│   ├── config.py
│   ├── ip_utils.py
│   ├── timestamp_utils.py
│   ├── rba_reader.py
│   ├── muestreo.py
│   ├── empleados.py
│   ├── ip_resolver.py
│   ├── features.py
│   ├── validacion.py
│   ├── diagnostico.py
│   ├── exportacion.py
│   └── pipeline.py
├── main.py
├── tests/
│   ├── conftest.py
│   ├── test_fase03.py
│   ├── legacy/
│   │   └── fase03_pipeline_v4.py
│   └── fixtures/
│       └── README.md
└── docs/
    └── FASE_03_INFORME_TECNICO.md
```

DEBES respetar esta arquitectura.

Puedes agregar módulos nuevos únicamente cuando exista una responsabilidad clara.

Por ejemplo, podrían evaluarse:

```text
fase03/
├── split.py
├── resampling.py
├── preprocessing.py
└── dimensionality.py
```

pero NO los agregues automáticamente.

Primero determina si realmente son necesarios.

No conviertas el proyecto en un único archivo.

No dupliques funcionalidades.

No hagas refactorizaciones cosméticas.

---

# 4. BASELINE YA VALIDADO

La versión modular anterior fue validada con:

```text
12 passed in 100.81s
```

Se validaron, entre otras cosas:

* equivalencia con monolito;
* reproducibilidad;
* ISO2;
* centroides;
* `country_mismatch`;
* NaN del primer evento;
* ventanas retrospectivas;
* `merge_asof`;
* ausencia de leakage;
* smoke test;
* separación del target.

El dataset producido anteriormente tenía:

```text
54.742 eventos
35 columnas
2.000 usuarios
```

y la comparación contra el monolito fue equivalente.

Estos resultados son un **baseline histórico**, no deben presentarse automáticamente como resultados de la nueva implementación.

---

# 5. DIAGNÓSTICO ATO YA CONOCIDO

El análisis anterior del RBA completo encontró:

```text
31.269.264 eventos
141 eventos ATO=True
138 usuarios ATO
```

De esos usuarios:

```text
43 usuarios ATO cumplen MIN_EVENTOS_USUARIO >= 15
95 usuarios ATO no cumplen el mínimo
```

La versión anterior seleccionaba 2.000 usuarios aleatoriamente y podía producir:

```text
0 ATO
```

Esto debe solucionarse metodológicamente.

---

# 6. PRIMERA FASE DE TU TRABAJO: AUDITORÍA

ANTES DE MODIFICAR CÓDIGO:

Inspecciona:

```text
fase03/
main.py
tests/
docs/
```

y determina:

1. arquitectura actual;
2. flujo actual;
3. estrategia de muestreo;
4. dónde se generan features;
5. dónde se separa el target;
6. dónde se realiza actualmente el export;
7. qué variables son numéricas;
8. qué variables son categóricas;
9. qué variables son binarias;
10. qué columnas son identificadores;
11. qué transformaciones existen;
12. si existe train/test;
13. si existe encoder;
14. si existe scaler;
15. si existe PCA;
16. posibles fuentes de leakage;
17. posibles problemas de memoria.

NO IMPLEMENTES todavía.

Primero entrega:

```text
ARCHIVOS ANALIZADOS

LO QUE YA FUNCIONA

LO QUE FALTA

RIESGOS METODOLÓGICOS

CAMBIOS PROPUESTOS
```

---

# 7. GRANULARIDAD DEL DATASET

Debes determinar explícitamente qué representa una fila.

El pipeline anterior trabaja a nivel de:

```text
evento de autenticación
```

No cambies silenciosamente esta granularidad.

Documenta:

```text
1 fila = 1 evento de autenticación
```

si esto continúa siendo cierto.

Esto es fundamental para el remuestreo.

---

# 8. TRAMPA CRÍTICA — USUARIO VS EVENTO

No confundas:

```text
cantidad de usuarios
```

con:

```text
cantidad de eventos
```

Un usuario puede tener muchos eventos.

Antes de implementar oversampling debes determinar exactamente:

* qué unidad se está remuestreando;
* qué representa una observación para Fase 4;
* cómo afecta el oversampling a eventos del mismo usuario.

No dupliques indiscriminadamente eventos si esto genera una representación metodológicamente problemática.

Documenta la decisión.

---

# 9. MUESTREO CON ATO

Implementa:

```python
MuestreoEstratificadoPorTarget
```

si la auditoría confirma que es la estrategia apropiada.

Debe garantizar que los usuarios seleccionados contengan ATO positivos reales.

No inventes ATO.

Los positivos deben proceder exclusivamente de:

```python
Is Account Takeover == True
```

El diagnóstico debe mostrar:

```text
ATO usuarios elegibles
ATO usuarios seleccionados
ATO eventos seleccionados
usuarios negativos
eventos negativos
```

---

# 10. NO ALTERAR ARBITRARIAMENTE MIN_EVENTOS_USUARIO

Existe:

```text
MIN_EVENTOS_USUARIO = 15
```

No reduzcas este valor solamente para aumentar artificialmente la cantidad de ATO.

Si consideras necesario modificarlo:

1. explica el problema;
2. presenta alternativas;
3. analiza consecuencias;
4. espera una decisión explícita o justifica metodológicamente el cambio;
5. documenta el cambio.

No ocultes el efecto sobre la población.

---

# 11. TRAIN / TEST

El split debe ocurrir:

```text
DESPUÉS DE CONSTRUIR LAS FEATURES
```

pero:

```text
ANTES DEL REMUESTREO
```

El split debe hacerse **por `User ID`**, no por filas.

Esto significa:

```python
set(train_users).isdisjoint(set(test_users))
```

debe ser verdadero.

Nunca debe ocurrir:

```text
Usuario A → TRAIN
Usuario A → TEST
```

porque eso puede producir leakage.

---

# 12. DISTRIBUCIÓN ATO ENTRE TRAIN Y TEST

Antes de remuestrear, calcula:

```text
ATO TRAIN original
ATO TEST original
usuarios ATO TRAIN
usuarios ATO TEST
prevalencia TRAIN
prevalencia TEST
```

Si el diseño del split no garantiza suficientes positivos en ambos conjuntos, detente y reporta el problema.

NO soluciones el problema duplicando positivos en TEST.

---

# 13. REGLA ABSOLUTA DEL TEST

El TEST debe representar datos no vistos.

Por lo tanto:

```text
TEST
NO oversampling
NO SMOTE
NO duplicación
NO ajuste de encoder
NO ajuste de scaler
NO ajuste de PCA
NO cálculo de parámetros con TEST
```

TEST solamente recibe transformaciones ya aprendidas de TRAIN.

---

# 14. REMUESTREO

Primero determina qué algoritmo se utilizará.

Opciones:

```text
RandomOverSampler
SMOTE
otra estrategia justificada
```

No utilices SMOTE automáticamente.

Evalúa:

* tipos de variables;
* categóricas;
* binarias;
* NaN;
* dimensionalidad;
* naturaleza de las features;
* necesidad real de interpolación.

Para este proyecto, considera especialmente si `RandomOverSampler` es suficiente y más fácil de justificar.

---

# 15. TRAMPA DE ORDEN DE TRANSFORMACIONES

NO asumas que existe un orden universal.

El orden depende del algoritmo de remuestreo.

Debes analizar específicamente los requisitos de la estrategia elegida.

Por ejemplo, conceptualmente puede ocurrir:

```text
SPLIT
 ↓
TRAIN / TEST
 ↓
PREPARACIÓN NECESARIA
 ↓
REPRESENTACIÓN COMPATIBLE CON EL REMUESTREADOR
 ↓
REMUESTREO SOLO TRAIN
 ↓
TRANSFORMACIONES POSTERIORES
 ↓
FASE 4
```

Si utilizas SMOTE:

* la representación debe ser numérica;
* no debe contener NaN;
* debes analizar cómo se representan las categóricas.

Si utilizas RandomOverSampler:

* verifica sus requisitos reales;
* no inventes restricciones;
* justifica dónde se coloca dentro del pipeline.

La regla fundamental es:

```text
NUNCA REMUESTREAR ANTES DEL SPLIT.
NUNCA REMUESTREAR TEST.
```

---

# 16. CATEGORIZACIÓN

Identifica todas las variables categóricas reales.

No asumas nombres sin inspeccionar el dataset.

Para variables nominales considera:

```python
OneHotEncoder(handle_unknown="ignore")
```

Para variables ordinales utiliza `OrdinalEncoder` únicamente cuando exista un orden semántico real.

No utilices `LabelEncoder` indiscriminadamente sobre features nominales.

Documenta:

```text
variable
tipo
transformación
justificación
```

---

# 17. VARIABLES BINARIAS

Identifica variables booleanas/binares.

Por ejemplo:

```text
Login Successful
Is Attack IP
has_previous_login
outside_shift
country_mismatch
inactive_account_success
impossible_travel
```

No necesariamente necesitan One-Hot Encoding.

Evalúa si deben convertirse a:

```text
0 / 1
```

cuando corresponda.

Documenta la decisión.

---

# 18. IMPUTACIÓN

Analiza todos los NaN.

NO hagas:

```python
fillna(0)
```

sin justificación.

Recuerda que anteriormente:

```text
distance_previous_km
time_since_previous_login_hours
```

pueden ser `NaN` cuando:

```text
has_previous_login = 0
```

Esto no significa necesariamente que sean errores.

Determina si:

* deben permanecer como NaN hasta una etapa concreta;
* deben imputarse;
* deben acompañarse de un indicador;
* el modelo/transformador elegido admite dicha representación.

Si se realiza imputación, el imputador debe ajustarse exclusivamente con TRAIN.

---

# 19. SCALER

Evalúa:

```text
MinMaxScaler
StandardScaler
RobustScaler
```

Selecciona uno basándote en las características reales del dataset.

Considera:

* outliers;
* distribuciones;
* distancia;
* velocidad;
* conteos;
* tiempos;
* otras variables numéricas.

Documenta la decisión.

Regla absoluta:

```python
scaler.fit(X_train)
```

y:

```python
X_test = scaler.transform(X_test)
```

Nunca:

```python
scaler.fit(pd.concat([X_train, X_test]))
```

Nunca:

```python
scaler.fit_transform(X_test)
```

---

# 20. ENCODER FIT SOLO TRAIN

El encoder debe ajustarse exclusivamente sobre TRAIN.

Nunca:

```python
encoder.fit(pd.concat([X_train, X_test]))
```

TEST debe utilizar:

```python
encoder.transform(X_test)
```

Usa:

```python
handle_unknown="ignore"
```

cuando corresponda.

Debe existir una prueba que simule una categoría presente en TEST pero ausente en TRAIN.

---

# 21. PIPELINE DE SKLEARN

Evalúa si la arquitectura puede beneficiarse de:

```text
Pipeline
ColumnTransformer
```

sin romper la arquitectura modular existente.

La solución debe permitir conceptualmente:

```text
TRAIN
 ↓
fit transformaciones
 ↓
transform TRAIN
 ↓
transform TEST
```

No dupliques manualmente la lógica de transformación si una abstracción de sklearn puede mantenerla correctamente.

Pero tampoco sobreingenierices.

---

# 22. PCA

PCA debe ser **validado**, no introducido ciegamente.

Analiza:

1. dimensionalidad antes de PCA;
2. dimensionalidad después de encoding;
3. necesidad de PCA;
4. compatibilidad con las variables;
5. efecto sobre interpretabilidad;
6. varianza explicada;
7. cantidad de componentes necesarias para 90%;
8. cantidad para 95%;
9. cantidad para 99%;
10. impacto sobre el Árbol de Decisión.

PCA debe ocurrir después de que la matriz tenga una representación numérica apropiada y haya recibido el preprocessing correspondiente.

Debe ajustarse exclusivamente sobre TRAIN:

```python
pca.fit(X_train)
```

y TEST:

```python
pca.transform(X_test)
```

Nunca:

```python
pca.fit(X_test)
```

ni:

```python
pca.fit(pd.concat([X_train, X_test]))
```

---

# 23. PCA NO ES OBLIGATORIO EN LA SALIDA FINAL

No incluyas PCA en el dataset final simplemente porque existe como técnica.

Determina si:

```text
PCA = transformación experimental
```

o:

```text
PCA = transformación final
```

Para un Árbol de Decisión, analiza específicamente la pérdida de interpretabilidad y si existe una necesidad real de reducción dimensional.

La decisión debe basarse en resultados reales.

---

# 24. TARGET LEAKAGE

El target es:

```text
Is Account Takeover
```

Debe mantenerse separado.

No debe estar en:

```text
X
features.py
preprocessor
scaler
encoder
PCA
```

Debe existir:

```python
X = features
y = target
```

y:

```python
assert "Is Account Takeover" not in X.columns
```

También:

```text
User ID
```

no debe utilizarse como predictor.

---

# 25. LEAKAGE INDIRECTO

Busca también:

* variables creadas a partir del target;
* estadísticas calculadas utilizando el target;
* selección condicionada al target que contamine las features;
* parámetros de preprocessing calculados usando TEST;
* información futura;
* eventos futuros dentro de features retrospectivas;
* usuarios compartidos entre train/test.

No te limites a comprobar si aparece literalmente:

```text
Is Account Takeover
```

---

# 26. ARQUITECTURA SOLID

Mantén los principios ya aplicados:

### SRP

Cada módulo debe tener una responsabilidad clara.

### OCP

La estrategia de muestreo debe poder sustituirse.

### DIP

`PipelineFase03` debe depender de abstracciones cuando tenga sentido.

No fuerces:

```text
ISP
LSP
```

si no aportan valor real.

No agregues clases solamente para poder decir que existen clases.

---

# 27. REPRODUCIBILIDAD

Mantén:

```text
RANDOM_STATE = 42
FAKER_SEED = 42
```

o los valores actualmente definidos.

Toda operación aleatoria debe depender de configuración.

La misma configuración debe producir resultados equivalentes.

---

# 28. TESTS OBLIGATORIOS

Amplía:

```text
tests/test_fase03.py
```

como mínimo con:

### Muestreo

1. target presente.
2. ATO positivos seleccionados.
3. reproducibilidad.
4. mínimo de eventos respetado.
5. cantidad de usuarios esperada.

### Split

6. train/test no comparten usuarios.
7. usuarios completos permanecen en un único conjunto.
8. positivos presentes en train cuando los datos lo permiten.
9. positivos presentes en test cuando los datos lo permiten.

### Remuestreo

10. solo TRAIN cambia.
11. TEST permanece intacto.
12. cantidad de positivos TRAIN aumenta o se modifica según estrategia.
13. cantidad de positivos TEST permanece igual.
14. no se generan usuarios nuevos.
15. no se realiza oversampling antes del split.

### Encoding

16. encoder ajustado únicamente con TRAIN.
17. categorías desconocidas en TEST no producen error.
18. train/test tienen la misma dimensionalidad final.

### Imputación

19. no existen NaN inesperados después del preprocessing.
20. imputador ajustado únicamente con TRAIN.

### Scaling

21. scaler ajustado únicamente con TRAIN.
22. test transformado sin refit.
23. transformación reproducible.

### PCA

24. PCA ajustado únicamente con TRAIN.
25. TEST se transforma sin refit.
26. explained variance válida.
27. dimensionalidad coherente.

### Leakage

28. target fuera de X.
29. User ID fuera de X.
30. target barajado no altera las features.
31. no existe información futura.
32. no existe solapamiento de usuarios.

### Calidad

33. no existen infinitos.
34. tipos numéricos correctos.
35. columnas críticas no desaparecen silenciosamente.

### Integración

36. smoke test completo con datos sintéticos.

No necesitas forzar exactamente 36 tests separados si varias validaciones pueden agruparse de manera limpia, pero TODAS estas propiedades deben estar cubiertas.

---

# 29. TESTS DE LEAKAGE DEL PREPROCESSING

Debes diseñar pruebas capaces de detectar accidentalmente:

```python
scaler.fit(train + test)
```

```python
encoder.fit(train + test)
```

```python
pca.fit(train + test)
```

y:

```python
oversampling antes del split
```

No basta con comprobar que los objetos existen.

La prueba debe detectar realmente la contaminación.

---

# 30. DATOS SINTÉTICOS PARA TESTS

Los tests unitarios NO deben depender de los 31 millones de eventos.

Utiliza fixtures pequeñas.

Los datos reales se utilizarán únicamente para la validación de integración que el usuario ejecutará posteriormente.

---

# 31. MEMORIA Y RENDIMIENTO

El pipeline anterior ya tiene problemas potenciales de memoria debido al tamaño del RBA.

Mantén:

```python
gc.collect()
```

cuando sea apropiado.

Mantén procesamiento por chunks.

Evita:

```python
pd.concat()
```

gigantescos innecesarios.

Evita múltiples `.copy()` de DataFrames grandes.

No cargues simultáneamente estructuras enormes si no es necesario.

Pero:

**NO afirmes cuánto tardó ni cuánta RAM utilizó el pipeline hasta que el usuario lo ejecute realmente.**

---

# 32. EJECUCIÓN REAL — PROCEDIMIENTO

Después de terminar implementación y tests locales/sintéticos:

NO ejecutes ni declares ejecutado el pipeline real si no tienes acceso al entorno.

En su lugar, entrega al usuario las celdas/comandos exactos:

```text
1. instalar dependencias si son necesarias
2. ejecutar tests
3. ejecutar pipeline real
4. ejecutar diagnóstico final
5. verificar archivos
```

Indica exactamente qué salida debe copiar el usuario.

Después de que el usuario proporcione esos logs:

1. analiza resultados;
2. detecta errores;
3. propone correcciones;
4. vuelve a generar código si es necesario;
5. indica nuevamente qué debe ejecutar.

---

# 33. FORMATO DE EVIDENCIA

Cuando un resultado no se ha ejecutado:

```text
ESTADO: PENDIENTE DE EJECUCIÓN
```

Cuando el usuario proporciona logs:

```text
ESTADO: EJECUTADO — EVIDENCIA PROPORCIONADA POR EL USUARIO
```

Cuando exista ejecución verificable dentro del entorno disponible:

```text
ESTADO: EJECUTADO — VERIFICADO
```

No utilices:

```text
VALIDADO
```

si realmente no existe evidencia.

---

# 34. DIAGNÓSTICO FINAL

Una vez que el usuario ejecute el pipeline real, el diagnóstico debe mostrar:

```text
============================================================
FASE 3 — DIAGNÓSTICO FINAL
============================================================

FUENTE
Eventos:
Usuarios:

ATO ORIGINAL
Usuarios:
Eventos:

SELECCIÓN
Usuarios:
Eventos:
ATO usuarios:
ATO eventos:

TRAIN
Usuarios:
Eventos:
ATO usuarios:
ATO eventos:
Prevalencia:

TEST
Usuarios:
Eventos:
ATO usuarios:
ATO eventos:
Prevalencia:

SOLAPAMIENTO DE USUARIOS:
0

REMUESTREO
Método:
Antes:
Después:
TRAIN afectado:
TEST afectado: NO

ENCODING
Método:
Variables:
Features generadas:

IMPUTACIÓN
Método:
NaN antes:
NaN después:

SCALER
Método:
Fit: TRAIN únicamente

PCA
Estado:
Componentes:
Varianza explicada:

INFINITOS
TRAIN:
TEST:

LEAKAGE
Target:
User ID:
Usuarios compartidos:
Encoder:
Scaler:
PCA:
Oversampling:

TESTS
...

RESULTADO
FASE 3: COMPLETADA / NO COMPLETADA
============================================================
```

Todos los números deben proceder de ejecución real.

---

# 35. EXPORTACIONES

Evalúa una salida como:

```text
dataset_train_prepared.csv
dataset_test_prepared.csv
```

y, cuando corresponda:

```text
preprocessor.joblib
```

o un pipeline serializado.

No guardes objetos innecesarios.

La Fase 4 debe poder cargar las transformaciones aprendidas sin volver a ajustarlas.

---

# 36. DOCUMENTACIÓN

Actualiza:

```text
docs/FASE_03_INFORME_TECNICO.md
```

Debe documentar:

1. objetivo;
2. fuentes;
3. muestreo;
4. ATO;
5. features;
6. granularidad;
7. train/test;
8. split por usuario;
9. remuestreo;
10. encoding;
11. imputación;
12. scaling;
13. PCA;
14. leakage;
15. arquitectura;
16. SOLID;
17. tests;
18. resultados reales;
19. limitaciones;
20. preparación para Fase 4.

No escribas resultados que todavía estén:

```text
PENDIENTE DE EJECUCIÓN
```

---

# 37. CRITERIOS DE CIERRE DE FASE 3

Solo puede declararse:

```text
FASE 3 COMPLETADA
```

cuando:

* [ ] ATO incorporado correctamente.
* [ ] ATO proveniente de datos reales del dataset.
* [ ] granularidad documentada.
* [ ] train/test separado por usuario.
* [ ] cero usuarios compartidos.
* [ ] suficientes positivos o limitación explícitamente documentada.
* [ ] remuestreo solo en TRAIN.
* [ ] TEST intacto.
* [ ] encoding implementado.
* [ ] encoding fit únicamente TRAIN.
* [ ] imputación validada.
* [ ] imputación fit únicamente TRAIN.
* [ ] scaler implementado.
* [ ] scaler fit únicamente TRAIN.
* [ ] PCA evaluado.
* [ ] PCA fit únicamente TRAIN.
* [ ] target fuera de X.
* [ ] User ID fuera de X.
* [ ] ausencia de leakage.
* [ ] ausencia de NaN inesperados.
* [ ] ausencia de infinitos.
* [ ] reproducibilidad.
* [ ] tests unitarios.
* [ ] tests de integración.
* [ ] pipeline real ejecutado por el usuario.
* [ ] logs reales analizados.
* [ ] archivos finales generados.
* [ ] documentación actualizada.

Si falta uno:

```text
FASE 3 NO COMPLETADA
```

---

# 38. ORDEN DE TRABAJO OBLIGATORIO

Trabaja en este orden:

## FASE A

Auditoría.

DETENTE.

Entrégame hallazgos.

## FASE B

Diseño de arquitectura.

DETENTE.

Indica:

```text
archivo
cambio
responsabilidad
justificación
```

## FASE C

Implementación.

## FASE D

Tests sintéticos/unitarios.

## FASE E

Presenta los comandos exactos que YO debo ejecutar sobre los datos reales.

NO inventes los resultados.

## FASE F

Yo te proporcionaré los logs.

## FASE G

Analiza los logs.

## FASE H

Corrige cualquier problema encontrado.

## FASE I

Vuelve a indicarme qué ejecutar.

## FASE J

Cuando exista evidencia real de que todo pasó, genera el diagnóstico final y actualiza la documentación.

---

# 39. CONDICIÓN FINAL

No busco una implementación que simplemente:

```text
"tenga SMOTE"
"tenga OneHotEncoder"
"tenga StandardScaler"
"tenga PCA"
```

Busco una Fase 3:

```text
METODOLÓGICAMENTE CORRECTA
        +
REPRODUCIBLE
        +
MODULAR
        +
SIN DATA LEAKAGE
        +
TESTEADA
        +
DOCUMENTADA
        +
LISTA PARA FASE 4
```

Si una técnica solicitada no resulta apropiada, debes demostrarlo mediante análisis y proponer una alternativa metodológicamente válida.

Si una técnica puede implementarse pero no debe formar parte del pipeline final, debes distinguir:

```text
IMPLEMENTACIÓN EXPERIMENTAL
```

de:

```text
PIPELINE PRINCIPAL
```

Nunca agregues complejidad únicamente para aparentar mayor sofisticación.

---

## COMIENZA AHORA

Empieza exclusivamente por:

# FASE A — AUDITORÍA

Inspecciona el proyecto existente.

NO modifiques código todavía.

NO inventes resultados.

NO ejecutes afirmaciones sobre datos reales que no puedas verificar.

Al finalizar la auditoría, entrégame:

1. arquitectura encontrada;
2. flujo actual;
3. clases existentes;
4. módulos existentes;
5. tests existentes;
6. estrategia actual de muestreo;
7. problemas encontrados;
8. riesgos de leakage;
9. variables candidatas a categorización;
10. variables candidatas a scaling;
11. viabilidad de PCA;
12. estrategia recomendada de remuestreo;
13. archivos que deberán modificarse;
14. archivos nuevos que realmente sean necesarios;
15. plan de implementación.

**Detente ahí y espera mi confirmación antes de comenzar la FASE B.**
