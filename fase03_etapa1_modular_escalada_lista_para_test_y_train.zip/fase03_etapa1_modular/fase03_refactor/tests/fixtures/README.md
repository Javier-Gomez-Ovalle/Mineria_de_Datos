# Fixtures reales pendientes

Para activar las Capas A y B de la suite de pruebas (equivalencia
end-to-end y reproducibilidad de empleados.csv contra el pipeline
monolítico, con datos REALES), copia aquí:

- `rba_2000_users.csv` (el archivo que ya generó tu corrida real en
  Colab — 54.742 filas)
- `country_asn.csv` (el catálogo IPinfo, ~230 MB)

O, si prefieres no duplicar archivos pesados, define las variables de
entorno antes de correr pytest:

```bash
export FASE03_RBA_2000_PATH=/ruta/a/tu/rba_2000_users.csv
export FASE03_IPINFO_PATH=/ruta/a/tu/country_asn.csv
pytest tests/ -v
```

Sin estos archivos, esas 2 pruebas se OMITEN (no fallan, no fingen
pasar) — el resto de la suite (Capas C, D, y el smoke test sintético)
corre siempre, sin depender de nada externo.
