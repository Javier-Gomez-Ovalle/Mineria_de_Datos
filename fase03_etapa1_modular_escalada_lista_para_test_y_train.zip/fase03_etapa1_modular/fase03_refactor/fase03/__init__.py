"""
Paquete fase03 — Preparación de Datos (CRISP-DM) para el proyecto de
detección predictiva de accesos anómalos.

Arquitectura modular, Etapa 1: refactor puro sobre fase03_pipeline_v4.py,
sin cambios metodológicos. Ver docs/FASE_03_INFORME_TECNICO.md para el
detalle de cada módulo y las decisiones de diseño.
"""
