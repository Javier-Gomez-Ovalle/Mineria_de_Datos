# CÓDIGO FUENTE Y PRUEBAS ACTIVAS - FASE 03

### ARCHIVO: fase03_refactor\Automatizar_empaquetado.py
```python
import os

# Carpeta raíz de tu proyecto refactorizado
CARPETA_PROYECTO = "fase03_refactor"
ARCHIVO_SALIDA = "proyecto_consolidado.md"

# Directorios a omitir para no saturar memoria
EXCLUIR = ["legacy", "fixtures", "__pycache__", ".pytest_cache", ".git"]

with open(ARCHIVO_SALIDA, "w", encoding="utf-8") as outfile:
    outfile.write("# CÓDIGO FUENTE Y PRUEBAS ACTIVAS - FASE 03\n\n")
    archivos_incluidos = 0

    for root, dirs, files in os.walk(CARPETA_PROYECTO):
        # Omitir carpetas no deseadas
        if any(ignorar in root for ignorar in EXCLUIR):
            continue

        for file in files:
            if file.endswith(".py"):
                filepath = os.path.join(root, file)
                outfile.write(f"### ARCHIVO: {filepath}\n")
                outfile.write("```python\n")
                with open(filepath, "r", encoding="utf-8") as infile:
                    outfile.write(infile.read())
                outfile.write("\n```\n\n")
                archivos_incluidos += 1
                print(f"Incluido: {filepath}")

print(
    f"\n¡Proceso completado! Se consolidaron {archivos_incluidos} archivos en '{ARCHIVO_SALIDA}'."
)
```

### ARCHIVO: fase03_refactor\main.py
```python
"""
main.py — punto de entrada ejecutable de la Fase 03.

Equivalente al bloque `if __name__ == "__main__": main()` del script
monolítico fase03_pipeline_v4.py. En Google Colab: sube la carpeta
fase03/ junto a este archivo a /content/, ajusta las rutas en
ConfiguracionPipeline si es necesario, y ejecuta `%run main.py` o
`python main.py`.
"""
from fase03.config import ConfiguracionPipeline
from fase03.muestreo import MuestreoAleatorioSimple
from fase03.pipeline import PipelineFase03


def main():
    config = ConfiguracionPipeline()
    estrategia = MuestreoAleatorioSimple(config)
    pipeline = PipelineFase03(config, estrategia)
    return pipeline.ejecutar()


if __name__ == "__main__":
    main()

```

### ARCHIVO: fase03_refactor\fase03\config.py
```python
"""
config.py
=========
Contenedor de configuración reproducible para la Fase 03 y catálogo de
constantes de dominio (roles hospitalarios, turnos, distribución de
países de residencia, centroides geográficos ISO2).

POR QUÉ EXISTE ESTE MÓDULO
--------------------------
En fase03_pipeline_v4.py (versión monolítica) estas constantes vivían
dispersas en el mismo archivo que la lógica que las consumía. Aislarlas
aquí permite que cualquier módulo (empleados.py, features.py) las
importe sin depender del resto del pipeline, y que cambiar una
ponderación no obligue a tocar lógica de negocio.

NO SE CAMBIA NINGÚN VALOR respecto a fase03_pipeline_v4.py — esto es
una reubicación (Etapa 1: refactor arquitectónico puro), no una
redefinición metodológica.
"""
from dataclasses import dataclass, field


@dataclass
class ConfiguracionPipeline:
    """Constantes reproducibles del pipeline. Equivalente tipado de la
    función configurar_entorno() del script monolítico.

    Todos los valores por defecto son idénticos a los de
    fase03_pipeline_v4.py. Se pueden sobreescribir por parámetro del
    constructor — por ejemplo, en pruebas, para apuntar a un fixture
    local en vez de /content (rutas de Google Colab).
    """

    RBA_PATH: str = "/content/rba_dataset.csv"
    IPINFO_PATH: str = "/content/country_asn.csv"
    OUT_RBA_2000: str = "/content/rba_2000_users.csv"
    OUT_EMPLEADOS: str = "/content/empleados.csv"
    OUT_DATASET_FINAL: str = "/content/dataset_final_modelo.csv"

    RANDOM_STATE: int = 42
    FAKER_SEED: int = 42

    MIN_EVENTOS_USUARIO: int = 15
    N_USUARIOS: int = 2000

    CHUNKSIZE_PASADA_1: int = 500_000
    CHUNKSIZE_PASADA_2: int = 250_000

    COLUMNAS_RBA_OBLIGATORIAS: list = field(default_factory=lambda: [
        "User ID",
        "IP Address",
        "Login Timestamp",
        "Login Successful",
        "Device Type",
        "Is Attack IP",
        "Is Account Takeover",
        "Country",
        "Region",
        "City",
        "ASN",
        "Round-Trip Time [ms]",
    ])

    VENTANA_CORTA: str = "15min"
    VENTANA_LARGA: str = "1h"

    UMBRAL_VELOCIDAD_KMH: float = 800.0
    VENTANA_MAX_HORAS: float = 12.0

    PESO_ASISTENCIAL_HOSPITALARIO: float = 0.80
    PROB_CUENTA_ACTIVA: float = 0.93

    # Ventana de recolección real del RBA Dataset, según su
    # documentación oficial. Se usa únicamente como verificación de
    # cordura no bloqueante sobre la unidad inferida del timestamp.
    VENTANA_FECHAS_RBA_CONOCIDA: tuple = ("2019-01-01", "2022-12-31")

    # Set de códigos ISO2 reconocidos por el pipeline (empleados +
    # centroides). Uso exclusivamente diagnóstico/informativo — nunca
    # se usa para inventar o corregir países no reconocidos.
    ISO2_RECONOCIDOS: set = field(default_factory=lambda: {
        "CO", "MX", "ES", "AR", "PE", "CL", "US", "EC",
        "BR", "VE", "DE", "FR", "GB", "CA", "CN", "IN", "RU", "JP",
    })


# ============================================================================
# CONSTANTES DE DOMINIO (idénticas a fase03_pipeline_v4.py — Etapa 1
# no introduce ningún cambio de valores ni de distribución)
# ============================================================================

ROLES_ASISTENCIALES = {
    "Médico Especialista": 0.18,
    "Médico General": 0.14,
    "Enfermero/a": 0.28,
    "Auxiliar de Enfermería": 0.20,
    "Farmacéutico/a": 0.10,
    "Personal de Laboratorio": 0.10,
}

ROLES_NO_ASISTENCIALES = {
    "Administrativo - Facturación": 0.30,
    "Administrativo - RRHH": 0.20,
    "Personal de TI / Soporte": 0.30,
    "Directivo / Gerencia": 0.20,
}

TURNOS = {
    "Diurno": 0.35,          # 06:00 - 14:00
    "Tarde": 0.25,           # 14:00 - 22:00
    "Nocturno": 0.25,        # 22:00 - 06:00 (cruza medianoche)
    "Administrativo": 0.15,  # 08:00 - 17:00
}

VENTANAS_TURNO = {
    "Diurno": (6, 14),
    "Tarde": (14, 22),
    "Nocturno": (22, 6),
    "Administrativo": (8, 17),
}

# ISO2 canónico (corrección de la Versión 4: antes eran nombres en
# español, lo cual rompía la comparación contra ip_country_code).
PAISES_RESIDENCIA_PESOS = {
    "CO": 0.72,  # Colombia
    "MX": 0.06,  # México
    "ES": 0.05,  # España
    "AR": 0.04,  # Argentina
    "PE": 0.04,  # Perú
    "CL": 0.03,  # Chile
    "US": 0.03,  # Estados Unidos
    "EC": 0.03,  # Ecuador
}

CIUDADES_POR_PAIS = {
    "CO": ["Bogotá", "Medellín", "Cali", "Barranquilla", "Ibagué", "Bucaramanga"],
    "MX": ["Ciudad de México", "Guadalajara", "Monterrey", "Puebla"],
    "ES": ["Madrid", "Barcelona", "Valencia", "Sevilla"],
    "AR": ["Buenos Aires", "Córdoba", "Rosario"],
    "PE": ["Lima", "Arequipa", "Cusco"],
    "CL": ["Santiago", "Valparaíso", "Concepción"],
    "US": ["Miami", "Houston", "Los Ángeles"],
    "EC": ["Quito", "Guayaquil", "Cuenca"],
}

# ISO2 canónico, alineado con el formato NATIVO de la columna
# 'Country' del RBA (que ya viene en ISO2, no en nombre de país).
CENTROIDES_GEOGRAFICOS = {
    "CO": (4.7110, -74.0721),    # Colombia
    "MX": (19.4326, -99.1332),   # México
    "ES": (40.4168, -3.7038),    # España
    "AR": (-34.6037, -58.3816),  # Argentina
    "PE": (-12.0464, -77.0428),  # Perú
    "CL": (-33.4489, -70.6693),  # Chile
    "US": (38.8951, -77.0364),   # Estados Unidos
    "EC": (-0.1807, -78.4678),   # Ecuador
    "BR": (-15.7939, -47.8828),  # Brasil
    "VE": (10.4806, -66.9036),   # Venezuela
    "DE": (52.5200, 13.4050),    # Alemania
    "FR": (48.8566, 2.3522),     # Francia
    "GB": (51.5074, -0.1278),    # Reino Unido
    "CA": (45.4215, -75.6972),   # Canadá
    "CN": (39.9042, 116.4074),   # China
    "IN": (28.6139, 77.2090),    # India
    "RU": (55.7558, 37.6173),    # Rusia
    "JP": (35.6762, 139.6503),   # Japón
}

```

### ARCHIVO: fase03_refactor\fase03\diagnostico.py
```python
"""
diagnostico.py
==============
Métricas descriptivas del dataset final + impresión del checklist
obligatorio. Se mantiene como FUNCIONES, mismo criterio que
validacion.py y features.py.
"""
import pandas as pd


def generar_metricas_diagnosticas(df, usuarios_seleccionados, diagnostico_global,
                                   diagnostico_subconjunto, diagnostico_resolucion,
                                   diagnostico_centroides, n_login_desconocidos,
                                   config):
    """Recolecta TODAS las métricas informativas para el checklist final."""
    metricas = {
        "n_usuarios_seleccionados": len(usuarios_seleccionados),
        "diagnostico_global": diagnostico_global,
        "diagnostico_subconjunto": diagnostico_subconjunto,
        "diagnostico_resolucion": diagnostico_resolucion,
        "diagnostico_centroides": diagnostico_centroides,
        "n_login_desconocidos": n_login_desconocidos,
    }

    usuarios_en_df = set(df["User ID"].unique())
    metricas["pct_integridad_referencial"] = (
        100 * len(usuarios_en_df & set(usuarios_seleccionados)) / len(usuarios_seleccionados)
        if usuarios_seleccionados else 0.0
    )

    metricas["orden_temporal_correcto"] = bool(
        df.groupby("User ID")["Login Timestamp"]
        .apply(lambda s: s.is_monotonic_increasing).all()
    )
    metricas["timestamp_es_datetime"] = pd.api.types.is_datetime64_any_dtype(
        df["Login Timestamp"]
    )
    metricas["rango_fechas_login"] = (
        str(df["Login Timestamp"].min()), str(df["Login Timestamp"].max())
    )

    conteo_gt = df["Is Account Takeover"].value_counts(dropna=False)
    metricas["ground_truth_counts"] = conteo_gt.to_dict()
    metricas["ground_truth_pct"] = (100 * conteo_gt / conteo_gt.sum()).round(2).to_dict()

    metricas["impossible_travel_total"] = int(df["impossible_travel"].sum())
    metricas["fuera_de_turno_total"] = int(df["is_outside_shift"].fillna(0).sum())
    metricas["inactive_success_total"] = int(df["inactive_account_success"].sum())

    metricas["has_previous_login_0"] = int((df["has_previous_login"] == 0).sum())
    metricas["has_previous_login_1"] = int((df["has_previous_login"] == 1).sum())

    metricas["country_mismatch_1"] = int(df["country_mismatch"].fillna(0).sum())
    metricas["country_mismatch_nan"] = int(df["country_mismatch"].isna().sum())

    paises_residencia_unicos = set(df["Pais_Residencia"].dropna().unique())
    metricas["paises_residencia_no_reconocidos"] = sorted(
        paises_residencia_unicos - config.ISO2_RECONOCIDOS
    )

    columnas_clave = [
        "ip_country_code", "ip_country_name", "distance_previous_km",
        "required_speed_kmh", "previous_login_timestamp",
        "login_exitoso_normalizado",
    ]
    metricas["nulos_columnas_clave"] = {
        c: int(df[c].isna().sum()) for c in columnas_clave if c in df.columns
    }

    print("  Resumen de métricas de calidad calculadas:")
    print(f"    Integridad referencial: {metricas['pct_integridad_referencial']:.2f}%")
    print(f"    Orden temporal correcto: {metricas['orden_temporal_correcto']}")
    print(f"    Rango de fechas de login: {metricas['rango_fechas_login']}")
    print(f"    Distribución Ground Truth: {metricas['ground_truth_counts']}")
    print(f"    has_previous_login=0 / =1: {metricas['has_previous_login_0']:,} / "
          f"{metricas['has_previous_login_1']:,}")
    print(f"    country_mismatch=1 / NaN: {metricas['country_mismatch_1']:,} / "
          f"{metricas['country_mismatch_nan']:,}")
    print(f"    Nulos en columnas clave: {metricas['nulos_columnas_clave']}\n")

    return metricas


def imprimir_checklist_final(df_final, metricas, config):
    """Checklist final con TODAS las métricas calculadas en tiempo real."""
    diag_sub = metricas["diagnostico_subconjunto"]
    diag_global = metricas["diagnostico_global"]
    diag_res = metricas["diagnostico_resolucion"]
    diag_cent = metricas["diagnostico_centroides"]
    gt_counts = metricas["ground_truth_counts"]
    gt_pct = metricas["ground_truth_pct"]

    print("=" * 60)
    print("CHECKLIST FINAL — FASE 03 CRISP-DM (Arquitectura modular, Etapa 1)")
    print("=" * 60)
    print()
    print(f"[OK] Usuarios seleccionados: {metricas['n_usuarios_seleccionados']}")
    print(f"[OK] Historial mínimo por usuario: >= {config.MIN_EVENTOS_USUARIO} eventos")
    print(f"[OK] Integridad referencial User ID: "
          f"{metricas['pct_integridad_referencial']:.2f}%")
    print()
    print(f"[INFO] Total registros procesados para los usuarios seleccionados: "
          f"{len(df_final):,}")
    print()
    print(f"[INFO] Rango de fechas de 'Login Timestamp': "
          f"{metricas['rango_fechas_login'][0]} -> {metricas['rango_fechas_login'][1]}")
    print()
    print(f"[INFO] --- Diagnóstico IP: SUBCONJUNTO de usuarios seleccionados ---")
    print(f"[INFO] IPv4: {diag_sub['total_ipv4']:,} ({diag_sub['pct_ipv4']:.2f}%)")
    print(f"[INFO] IPv6: {diag_sub['total_ipv6']:,} ({diag_sub['pct_ipv6']:.2f}%)")
    print(f"[INFO] IP inválidas/nulas: {diag_sub['total_invalidas']:,} "
          f"({diag_sub['pct_invalidas']:.2f}%)")
    print()
    print(f"[INFO] --- Diagnóstico IP: RBA GLOBAL, solo referencia ---")
    print(f"[INFO] IPv4: {diag_global['total_ipv4']:,} ({diag_global['pct_ipv4']:.2f}%)")
    print(f"[INFO] IPv6: {diag_global['total_ipv6']:,} ({diag_global['pct_ipv6']:.2f}%)")
    print(f"[INFO] IP inválidas/nulas: {diag_global['total_invalidas']:,} "
          f"({diag_global['pct_invalidas']:.2f}%)")
    print()
    print(f"[INFO] IPs IPv4 resueltas mediante IPinfo: "
          f"{diag_res['ipv4_unicas_resueltas']:,}")
    print(f"[INFO] IPs IPv4 no resueltas: {diag_res['ipv4_unicas_no_resueltas']:,}")
    print(f"[INFO] Porcentaje de resolución IPv4: "
          f"{diag_res['pct_resolucion_ipv4']:.2f}%")
    print()
    print(f"[INFO] Cobertura centroides ISO2 (países distintos): "
          f"{diag_cent['pct_cobertura_paises_distintos']:.2f}% "
          f"({diag_cent['paises_con_centroide']}/{diag_cent['paises_relevantes_total']})")
    print(f"[INFO] Cobertura centroides (registros con historial previo): "
          f"{diag_cent['pct_cobertura_registros_con_historial']:.2f}%")
    print()
    print(f"[INFO] has_previous_login = 0 (primer evento): "
          f"{metricas['has_previous_login_0']:,}")
    print(f"[INFO] has_previous_login = 1 (con historial): "
          f"{metricas['has_previous_login_1']:,}")
    print()
    print(f"[INFO] impossible_travel = 1: {metricas['impossible_travel_total']:,}")
    print(f"[INFO] registros fuera de turno: {metricas['fuera_de_turno_total']:,}")
    print(f"[INFO] cuentas inactivas con login exitoso: "
          f"{metricas['inactive_success_total']:,}")
    print(f"[INFO] valores de 'Login Successful' no interpretables: "
          f"{metricas['n_login_desconocidos']:,}")
    print()
    print(f"[INFO] country_mismatch = 1: {metricas['country_mismatch_1']:,}")
    print(f"[INFO] country_mismatch = NaN (IP no resuelta): "
          f"{metricas['country_mismatch_nan']:,}")
    if metricas["paises_residencia_no_reconocidos"]:
        print(f"[ATENCIÓN] Códigos ISO2 en Pais_Residencia fuera del set "
              f"reconocido: {metricas['paises_residencia_no_reconocidos']}")
    else:
        print("[OK] Todos los códigos ISO2 de Pais_Residencia están dentro "
              "del set reconocido.")
    print()
    print(f"[INFO] Nulos en columnas clave: {metricas['nulos_columnas_clave']}")
    print()
    print(f"[INFO] Orden temporal correcto: {metricas['orden_temporal_correcto']}")
    print(f"[INFO] Timestamp es datetime: {metricas['timestamp_es_datetime']}")
    print()
    print("[INFO] Distribución Ground Truth:")
    for valor, conteo in gt_counts.items():
        print(f"       Is Account Takeover = {valor}: {conteo:,} "
              f"({gt_pct.get(valor, 0):.2f}%)")
    print()
    print("[INFO] Dataset final:")
    print(f"       Filas: {len(df_final):,}")
    print(f"       Columnas: {df_final.shape[1]}")
    print()
    print("[OK] No se ejecutó entrenamiento de Machine Learning.")
    print("[OK] No se ejecutó SMOTE ni balanceo de clases.")
    print("[OK] No se realizó train_test_split.")
    print("[OK] No se realizaron predicciones.")
    print("[OK] 'Is Account Takeover' fue retirado físicamente del DataFrame "
          "antes de construir features y reincorporado solo para validación/"
          "exportación (barrera estructural anti-leakage).")
    print("[OK] Fase 03 (arquitectura modular, Etapa 1) finalizada.")
    print()
    print("Archivo generado:")
    print(config.OUT_DATASET_FINAL)
    print()
    print("=" * 60)

```

### ARCHIVO: fase03_refactor\fase03\empleados.py
```python
"""
empleados.py
============
Generación del maestro sintético de empleados (empleados.csv).

POR QUÉ ES UNA CLASE (justificación real, no nominal)
------------------------------------------------------
GeneradorEmpleados agrupa: (a) las distribuciones ponderadas de roles/
turnos/países (importadas de config.py), (b) el estado de los
generadores aleatorios (Faker + numpy Generator, ambos sembrados desde
config), y (c) las validaciones de integridad post-generación. Todo
esto se usa en una sola llamada (generar()), pero mantenerlo agrupado
en una clase deja explícito que la reproducibilidad depende del mismo
config en TODO el proceso — no es solo "una función con muchos
parámetros".

Pais_Residencia se genera DIRECTAMENTE como código ISO2 canónico
(ej. 'CO'), no como nombre en español — esta es la corrección aplicada
en la Versión 4 para permitir comparación directa contra
ip_country_code en features.py, sin fricción de idioma.
"""
import random

import numpy as np
import pandas as pd
from faker import Faker

from .config import (
    ROLES_ASISTENCIALES,
    ROLES_NO_ASISTENCIALES,
    TURNOS,
    PAISES_RESIDENCIA_PESOS,
    CIUDADES_POR_PAIS,
)


def _construir_lista_ponderada(pesos_dict):
    """Función pura auxiliar, sin estado — no forma parte del
    contrato público de GeneradorEmpleados."""
    etiquetas = list(pesos_dict.keys())
    pesos = np.array(list(pesos_dict.values()), dtype=float)
    pesos = pesos / pesos.sum()
    return etiquetas, pesos


class GeneradorEmpleados:
    def __init__(self, config):
        self.config = config

    def generar(self, usuarios_seleccionados):
        """Genera empleados.csv con EXACTAMENTE los User ID reales
        pasados en usuarios_seleccionados. Atributos 100% sintéticos
        (Faker, seed reproducible). Ciudad_Base coherente con
        Pais_Residencia (ISO2)."""
        config = self.config
        print("=" * 60)
        print("[5/8] Generando maestro sintético de empleados...")
        print("=" * 60)

        Faker.seed(config.FAKER_SEED)
        fake = Faker()
        rng = np.random.default_rng(config.RANDOM_STATE)
        rng_python = random.Random(config.RANDOM_STATE)

        peso_asistencial = config.PESO_ASISTENCIAL_HOSPITALARIO
        peso_no_asistencial = 1.0 - peso_asistencial

        roles_etiquetas = list(ROLES_ASISTENCIALES.keys()) + list(ROLES_NO_ASISTENCIALES.keys())
        roles_pesos = np.array(
            [w * peso_asistencial for w in ROLES_ASISTENCIALES.values()] +
            [w * peso_no_asistencial for w in ROLES_NO_ASISTENCIALES.values()]
        )
        roles_pesos = roles_pesos / roles_pesos.sum()

        turnos_etiquetas, turnos_pesos = _construir_lista_ponderada(TURNOS)
        paises_etiquetas, paises_pesos = _construir_lista_ponderada(PAISES_RESIDENCIA_PESOS)

        n = len(usuarios_seleccionados)

        roles_asignados = rng.choice(roles_etiquetas, size=n, p=roles_pesos)
        turnos_asignados = rng.choice(turnos_etiquetas, size=n, p=turnos_pesos)
        paises_asignados = rng.choice(paises_etiquetas, size=n, p=paises_pesos)
        estados_cuenta = rng.choice(
            ["Activo", "Inactivo"], size=n,
            p=[config.PROB_CUENTA_ACTIVA, 1 - config.PROB_CUENTA_ACTIVA],
        )

        registros = []
        for i, uid in enumerate(usuarios_seleccionados):
            pais_iso2 = paises_asignados[i]
            ciudades_del_pais = CIUDADES_POR_PAIS.get(pais_iso2, ["Ciudad no catalogada"])
            ciudad = rng_python.choice(ciudades_del_pais)

            registros.append({
                "User ID": uid,
                "Nombre_Completo": fake.name(),
                "Rol_Hospitalario": roles_asignados[i],
                "Pais_Residencia": pais_iso2,
                "Ciudad_Base": ciudad,
                "Turno_Asignado": turnos_asignados[i],
                "Estado_Cuenta": estados_cuenta[i],
                "Fecha_Ingreso": fake.date_between(start_date="-10y", end_date="-1y"),
            })

        df_empleados = pd.DataFrame(registros)

        self._validar_integridad(df_empleados, usuarios_seleccionados)

        iso2_no_reconocidos = set(df_empleados["Pais_Residencia"].unique()) - config.ISO2_RECONOCIDOS
        if iso2_no_reconocidos:
            print(f"  [ATENCIÓN] Códigos ISO2 generados fuera del set reconocido: "
                  f"{iso2_no_reconocidos}. Revisa PAISES_RESIDENCIA_PESOS.")
        else:
            print("  [OK] Todos los códigos ISO2 de 'Pais_Residencia' están dentro "
                  "del set reconocido por el pipeline.")

        df_empleados.to_csv(config.OUT_EMPLEADOS, index=False)

        print(f"  Empleados generados: {len(df_empleados):,}")
        print("  [OK] Integridad referencial (User ID): 100% verificado")
        print("  [OK] Coherencia Pais_Residencia (ISO2) / Ciudad_Base: 100% verificado")
        print("  Distribución de roles (asistencial vs. no asistencial):")
        print(df_empleados["Rol_Hospitalario"].value_counts(normalize=True)
              .mul(100).round(1).to_string())
        print(f"  Archivo generado: {config.OUT_EMPLEADOS}\n")

        return df_empleados

    def _validar_integridad(self, df_empleados, usuarios_seleccionados):
        """Método privado: validaciones bloqueantes post-generación,
        idénticas a las de generar_empleados() en fase03_pipeline_v4.py."""
        config = self.config

        if set(df_empleados["User ID"]) != set(usuarios_seleccionados):
            raise RuntimeError(
                "ERROR CRÍTICO DE INTEGRIDAD REFERENCIAL: los User ID de "
                "empleados.csv no coinciden 100% con los usuarios extraídos "
                "del RBA."
            )
        if len(df_empleados) != config.N_USUARIOS:
            raise RuntimeError(
                f"ERROR CRÍTICO: empleados.csv tiene {len(df_empleados)} filas, "
                f"se esperaban exactamente {config.N_USUARIOS}."
            )
        if not pd.api.types.is_integer_dtype(df_empleados["User ID"]):
            raise RuntimeError(
                "El dtype de 'User ID' en empleados.csv debe ser entero (int64)."
            )

        incoherentes = df_empleados.apply(
            lambda r: r["Ciudad_Base"] not in CIUDADES_POR_PAIS.get(r["Pais_Residencia"], []),
            axis=1,
        ).sum()
        if incoherentes > 0:
            raise RuntimeError(
                f"ERROR CRÍTICO: {incoherentes} empleados tienen Ciudad_Base "
                "incoherente con su Pais_Residencia."
            )

```

### ARCHIVO: fase03_refactor\fase03\exportacion.py
```python
"""
exportacion.py
==============
Selección de columnas finales + escritura de dataset_final_modelo.csv.
Se mantiene como FUNCIÓN, mismo criterio que validacion.py/features.py.
"""


def exportar_dataset_final(df, config):
    """Exporta dataset_final_modelo.csv. 'Is Account Takeover' queda
    como ÚLTIMA columna, sin modificaciones."""
    columnas_finales = [
        "User ID", "IP Address", "Login Timestamp", "Login Successful",
        "login_exitoso_normalizado",
        "Device Type", "Is Attack IP",
        "Country", "Region", "City", "ASN",
        "ip_country_code", "ip_country_name", "ip_asn", "ip_as_name", "ip_as_domain",
        "Nombre_Completo", "Rol_Hospitalario", "Pais_Residencia",
        "Ciudad_Base", "Turno_Asignado", "Estado_Cuenta", "Fecha_Ingreso",
        "failed_attempts_15min", "failed_attempts_1h",
        "has_previous_login",
        "previous_login_timestamp", "time_since_previous_login_hours",
        "distance_previous_km", "required_speed_kmh", "impossible_travel",
        "is_outside_shift", "country_mismatch", "inactive_account_success",
        "Is Account Takeover",
    ]
    columnas_presentes = [c for c in columnas_finales if c in df.columns]
    df_final = df[columnas_presentes]

    df_final.to_csv(config.OUT_DATASET_FINAL, index=False)
    return df_final

```

### ARCHIVO: fase03_refactor\fase03\features.py
```python
"""
features.py
===========
Ingeniería de características. Se mantienen como FUNCIONES DE MÓDULO,
no como clases — decisión explícita de la revisión crítica de diseño:
cada una tiene un solo método público, sin estado propio más allá de
'config', y el orden entre ellas es fijo (crear_features_temporales
debe correr antes que crear_feature_impossible_travel y
crear_feature_turnos, porque ambas dependen de columnas que la primera
crea). Al no ser intercambiables ni tener estado propio, envolverlas en
clases habría sido cumplimiento cosmético de "necesitamos clases", no
una necesidad arquitectónica real.

BARRERA DE NO-LEAKAGE (aplicada por el orquestador, no aquí)
--------------------------------------------------------------
Ninguna función de este módulo lee ni necesita leer 'Is Account
Takeover'. Esa garantía se refuerza estructuralmente en pipeline.py:
la columna se retira físicamente del DataFrame (df.pop(...)) ANTES de
que estas funciones se ejecuten, por lo que ni siquiera podría leerse
por accidente. Ver tests/test_fase03.py::test_no_leakage_barajar_target
para la prueba que lo demuestra empíricamente.
"""
import numpy as np
import pandas as pd

from .config import CENTROIDES_GEOGRAFICOS, VENTANAS_TURNO
from .timestamp_utils import convertir_login_timestamp

VALORES_LOGIN_EXITOSO = {"true", "1", "1.0", "yes", "y", "t", "success", "successful"}
VALORES_LOGIN_FALLIDO = {"false", "0", "0.0", "no", "n", "f", "fail", "failed", "failure"}


def normalizar_login_successful(serie):
    """Conversión DEFENSIVA de 'Login Successful': reconoce booleanos
    nativos, texto ('True'/'False'/'yes'/'no', etc.) y 0/1. Un valor
    ambiguo se marca NaN — NUNCA se asume como éxito o fracaso."""
    def _clasificar(valor):
        if pd.isna(valor):
            return np.nan
        if isinstance(valor, (bool, np.bool_)):
            return bool(valor)
        if isinstance(valor, (int, float, np.integer, np.floating)):
            if valor == 1:
                return True
            if valor == 0:
                return False
            return np.nan
        texto = str(valor).strip().lower()
        if texto in VALORES_LOGIN_EXITOSO:
            return True
        if texto in VALORES_LOGIN_FALLIDO:
            return False
        return np.nan

    valores_originales_unicos = serie.value_counts(dropna=False)
    print("  Valores originales detectados en 'Login Successful':")
    print(valores_originales_unicos.to_string())

    normalizado = serie.apply(_clasificar)
    n_desconocidos = int(normalizado.isna().sum() - serie.isna().sum())

    if n_desconocidos > 0:
        print(f"  [ATENCIÓN] {n_desconocidos:,} valores de 'Login Successful' "
              "no pudieron interpretarse de forma segura y se marcaron como "
              "NaN (política explícita: NO se asumen como éxito ni como "
              "fracaso).")
    else:
        print("  [OK] Todos los valores de 'Login Successful' se "
              "interpretaron correctamente.")

    return normalizado, n_desconocidos


def calcular_rolling_retrospectivo(df, columna_valor, ventana):
    """Ventana móvil retrospectiva (closed='left') POR USUARIO, con
    alineación EXPLÍCITA de índice.

    Se itera manualmente sobre los grupos y se concatena con
    pd.concat(), en vez de usar groupby().apply(): en pandas >= 3.0,
    groupby().apply() puede devolver un DataFrame de una sola fila
    (en vez de concatenar las Series por grupo) cuando el DataFrame
    contiene EXACTAMENTE UN grupo. Con los usuarios reales del
    pipeline esto no ocurre, pero la función no debería depender
    implícitamente de "haber más de un usuario" para ser correcta."""
    partes = []
    for _, grupo in df.groupby("User ID", sort=False):
        serie_temporal = grupo.set_index("Login Timestamp")[columna_valor]
        resultado = serie_temporal.rolling(ventana, closed="left").sum()
        resultado.index = grupo.index
        partes.append(resultado)

    resultados = pd.concat(partes) if partes else pd.Series(dtype=float)
    return resultados.reindex(df.index)


def crear_features_temporales(df, config):
    """Construye failed_attempts_15min/1h, previous_login_timestamp,
    previous_ip, previous_country, time_since_previous_login_hours y
    has_previous_login."""
    print("=" * 60)
    print("[7/8] Creando features de ingeniería (fuerza bruta, temporales)...")
    print("=" * 60)

    print("  Convirtiendo 'Login Timestamp' (entero Unix de 64 bits)...")
    df["Login Timestamp"] = convertir_login_timestamp(
        df["Login Timestamp"], config.VENTANA_FECHAS_RBA_CONOCIDA
    )
    df = df.sort_values(["User ID", "Login Timestamp"]).reset_index(drop=True)

    print("\n  Normalizando 'Login Successful'...")
    login_normalizado, n_desconocidos = normalizar_login_successful(df["Login Successful"])
    df["login_exitoso_normalizado"] = login_normalizado

    # Máscara de FALLOS EXPLÍCITOS únicamente. Un valor desconocido
    # (NaN) no cuenta como fallo ni como éxito dentro de la ventana de
    # fuerza bruta.
    mascara_fallo_explicito = df["login_exitoso_normalizado"] == False  # noqa: E712
    df["is_failed"] = mascara_fallo_explicito.astype(int)

    df["failed_attempts_15min"] = calcular_rolling_retrospectivo(
        df, "is_failed", config.VENTANA_CORTA
    ).fillna(0)
    df["failed_attempts_1h"] = calcular_rolling_retrospectivo(
        df, "is_failed", config.VENTANA_LARGA
    ).fillna(0)

    grp = df.groupby("User ID")
    df["previous_login_timestamp"] = grp["Login Timestamp"].shift(1)
    df["previous_ip"] = grp["IP Address"].shift(1)
    df["previous_country"] = grp["Country"].shift(1)
    del grp

    df["has_previous_login"] = df["previous_login_timestamp"].notna().astype(int)

    delta = df["Login Timestamp"] - df["previous_login_timestamp"]
    df["time_since_previous_login_hours"] = delta.dt.total_seconds() / 3600.0
    del delta

    print(f"\n  failed_attempts_15min -> media: "
          f"{df['failed_attempts_15min'].mean():.3f}")
    print(f"  failed_attempts_1h    -> media: "
          f"{df['failed_attempts_1h'].mean():.3f}")
    print(f"  has_previous_login = 0 (primer evento por usuario): "
          f"{int((df['has_previous_login'] == 0).sum()):,}")
    print(f"  has_previous_login = 1 (con historial previo): "
          f"{int((df['has_previous_login'] == 1).sum()):,}")
    print(f"  Valores de Login Successful no interpretables: {n_desconocidos:,}\n")

    return df, n_desconocidos


def _distancia_haversine(lat1, lon1, lat2, lon2):
    """Distancia aproximada (km) entre dos puntos, fórmula de Haversine."""
    if any(pd.isna(v) for v in [lat1, lon1, lat2, lon2]):
        return np.nan
    R = 6371.0
    lat1_r, lon1_r, lat2_r, lon2_r = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2_r - lat1_r
    dlon = lon2_r - lon1_r
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1_r) * np.cos(lat2_r) * np.sin(dlon / 2) ** 2
    c = 2 * np.arcsin(np.sqrt(a))
    return R * c


def crear_feature_impossible_travel(df, config):
    """Impossible Travel sobre 'Country' ORIGINAL del RBA (actual y
    anterior) -> centroide representativo ISO2. Refuerza NaN explícito
    en distance_previous_km/required_speed_kmh cuando
    has_previous_login == 0."""
    print("  Calculando Impossible Travel (Haversine + centroides ISO2 sobre "
          "'Country' original del RBA)...")

    def _lat(pais_iso2):
        return CENTROIDES_GEOGRAFICOS.get(pais_iso2, (np.nan, np.nan))[0]

    def _lon(pais_iso2):
        return CENTROIDES_GEOGRAFICOS.get(pais_iso2, (np.nan, np.nan))[1]

    df["_lat_actual"] = df["Country"].apply(_lat)
    df["_lon_actual"] = df["Country"].apply(_lon)
    df["_lat_previa"] = df["previous_country"].apply(_lat)
    df["_lon_previa"] = df["previous_country"].apply(_lon)

    df["distance_previous_km"] = df.apply(
        lambda r: _distancia_haversine(
            r["_lat_previa"], r["_lon_previa"], r["_lat_actual"], r["_lon_actual"]
        ),
        axis=1,
    )

    tiempo_valido = (
        df["time_since_previous_login_hours"].notna()
        & (df["time_since_previous_login_hours"] > 0)
    )
    distancia_valida = df["distance_previous_km"].notna()
    mascara_calculable = tiempo_valido & distancia_valida

    df["required_speed_kmh"] = np.nan
    df.loc[mascara_calculable, "required_speed_kmh"] = (
        df.loc[mascara_calculable, "distance_previous_km"]
        / df.loc[mascara_calculable, "time_since_previous_login_hours"]
    )

    sin_historial = df["has_previous_login"] == 0
    df.loc[sin_historial, "distance_previous_km"] = np.nan
    df.loc[sin_historial, "required_speed_kmh"] = np.nan

    df["impossible_travel"] = 0
    condicion_anomalia = (
        mascara_calculable
        & (~sin_historial)
        & (df["required_speed_kmh"] > config.UMBRAL_VELOCIDAD_KMH)
        & (df["time_since_previous_login_hours"] < config.VENTANA_MAX_HORAS)
    )
    df.loc[condicion_anomalia, "impossible_travel"] = 1

    paises_relevantes = pd.concat(
        [df["Country"], df["previous_country"]]
    ).dropna().unique()
    paises_con_centroide = [p for p in paises_relevantes if p in CENTROIDES_GEOGRAFICOS]
    pct_cobertura_paises = (
        100 * len(paises_con_centroide) / len(paises_relevantes)
        if len(paises_relevantes) else 0.0
    )

    con_historial = df["has_previous_login"] == 1
    if con_historial.sum() > 0:
        ambos_con_centroide = (
            df.loc[con_historial, "Country"].isin(CENTROIDES_GEOGRAFICOS)
            & df.loc[con_historial, "previous_country"].isin(CENTROIDES_GEOGRAFICOS)
        )
        pct_cobertura_registros = 100 * ambos_con_centroide.sum() / con_historial.sum()
    else:
        pct_cobertura_registros = 0.0

    diagnostico_centroides = {
        "paises_relevantes_total": len(paises_relevantes),
        "paises_con_centroide": len(paises_con_centroide),
        "pct_cobertura_paises_distintos": pct_cobertura_paises,
        "pct_cobertura_registros_con_historial": pct_cobertura_registros,
    }

    df = df.drop(columns=["_lat_actual", "_lon_actual", "_lat_previa", "_lon_previa"])

    print(f"    Cobertura de centroides (países distintos, ISO2): "
          f"{len(paises_con_centroide)}/{len(paises_relevantes)} "
          f"({pct_cobertura_paises:.2f}%)")
    print(f"    Cobertura de centroides (registros con historial previo): "
          f"{pct_cobertura_registros:.2f}%")
    print(f"    impossible_travel = 1 -> {int(df['impossible_travel'].sum()):,} registros")
    print(f"    (heurística: velocidad > {config.UMBRAL_VELOCIDAD_KMH} km/h "
          f"Y ventana < {config.VENTANA_MAX_HORAS}h)\n")

    return df, diagnostico_centroides


def crear_feature_turnos(df):
    """is_outside_shift, respetando turnos que cruzan medianoche."""
    print("  Calculando is_outside_shift (respetando turnos nocturnos)...")

    def _fuera_de_turno(hora, turno):
        if turno not in VENTANAS_TURNO or pd.isna(hora):
            return np.nan
        inicio, fin = VENTANAS_TURNO[turno]
        if inicio < fin:
            dentro = inicio <= hora < fin
        else:
            dentro = hora >= inicio or hora < fin
        return 0 if dentro else 1

    df["_hora_login"] = df["Login Timestamp"].dt.hour
    df["is_outside_shift"] = df.apply(
        lambda r: _fuera_de_turno(r["_hora_login"], r.get("Turno_Asignado", np.nan)),
        axis=1,
    )
    df = df.drop(columns=["_hora_login"])

    print(f"    Registros fuera de turno: "
          f"{int(df['is_outside_shift'].fillna(0).sum()):,}\n")
    return df


def crear_features_negocio(df):
    """country_mismatch (ISO2 de Pais_Residencia vs ISO2 nativo de
    ip_country_code, ambos normalizados a mayúsculas) e
    inactive_account_success."""
    print("  Calculando country_mismatch e inactive_account_success...")

    if "ip_country_code" not in df.columns:
        raise RuntimeError(
            "ERROR: 'ip_country_code' no está disponible; country_mismatch "
            "requiere el código ISO2 resuelto por IPinfo."
        )

    pais_residencia_iso2 = df["Pais_Residencia"].astype("string").str.upper()
    ip_country_code_iso2 = df["ip_country_code"].astype("string").str.upper()

    ambos_conocidos = pais_residencia_iso2.notna() & ip_country_code_iso2.notna()
    df["country_mismatch"] = np.nan
    df.loc[ambos_conocidos, "country_mismatch"] = (
        pais_residencia_iso2[ambos_conocidos] != ip_country_code_iso2[ambos_conocidos]
    ).astype(int)

    df["inactive_account_success"] = (
        (df["Estado_Cuenta"] == "Inactivo")
        & (df["login_exitoso_normalizado"] == True)  # noqa: E712
    ).astype(int)

    n_no_resuelto = int((~ambos_conocidos).sum())
    print(f"    country_mismatch = 1 -> "
          f"{int(df['country_mismatch'].fillna(0).sum()):,} registros")
    print(f"    country_mismatch = NaN (IP no resuelta u otro dato faltante): "
          f"{n_no_resuelto:,} registros")
    print(f"    inactive_account_success = 1 -> "
          f"{int(df['inactive_account_success'].sum()):,} registros\n")

    return df

```

### ARCHIVO: fase03_refactor\fase03\ip_resolver.py
```python
"""
ip_resolver.py
==============
Resolución de rangos IP mediante IPinfo + pd.merge_asof (solo
enriquecimiento — NUNCA sustituye 'Country'/'Region'/'City' originales
del RBA).

POR QUÉ ES UNA CLASE (justificación real, no nominal)
------------------------------------------------------
ResolutorIPinfo agrupa la ruta del catálogo IPinfo (config) con una
secuencia de pasos que comparten variables intermedias (clasificación
de IPs, construcción de rangos, merge_asof, validación de rango). Es
un único método público (resolver()), pero con lógica interna multi-
paso no trivial que se beneficia de quedar autocontenida en su propio
módulo/clase en vez de vivir como función de 150 líneas en el
orquestador.

CONTIENE EL FIX DE DTYPE YA VALIDADO
-------------------------------------
'ip_int' (lado RBA) puede nacer float64 si en algún punto del archivo
completo existen IPs IPv6/inválidas (fuerzan NaN a nivel de columna).
'start_ip_int'/'end_ip_int' (lado IPinfo) pueden nacer int64 si el
catálogo no contiene ninguna entrada inválida. pd.merge_asof() exige
que ambas claves compartan dtype. La corrección castea EXPLÍCITAMENTE
a int64 ambos lados, SOLO después de garantizar la ausencia de NaN en
el subconjunto que participa del merge (ver comentarios inline). Esta
corrección NO se elimina ni se modifica en este refactor.
"""
import pandas as pd
import numpy as np

from .ip_utils import clasificar_ip


class ResolutorIPinfo:
    def __init__(self, config):
        self.config = config

    def resolver(self, df_logs):
        """Enriquece cada IP con datos de IPinfo. Enriquecimiento
        ADICIONAL, NUNCA sustituye 'Country'/'Region'/'City' originales
        del RBA. Las columnas nuevas llevan prefijo 'ip_'.

        'ip_country_code' es el código ISO2 nativo de 2 letras que
        entrega IPinfo en su columna 'country' — esta es la columna
        que se usa en features.py para 'country_mismatch', NUNCA
        'ip_country_name'.
        """
        config = self.config
        print("=" * 60)
        print("[6/8] Resolviendo rangos IP mediante IPinfo (solo enriquecimiento)...")
        print("=" * 60)

        clasificacion = df_logs["IP Address"].apply(clasificar_ip)
        df_logs["ip_int"] = clasificacion.apply(lambda t: t[0])
        df_logs["ip_version"] = clasificacion.apply(lambda t: t[1])
        del clasificacion

        total_ips = len(df_logs)
        total_ipv4 = int((df_logs["ip_version"] == 4).sum())
        total_ipv6 = int((df_logs["ip_version"] == 6).sum())
        total_invalidas = int(df_logs["ip_version"].isna().sum())

        df_ipinfo = pd.read_csv(config.IPINFO_PATH)

        columnas_ipinfo_esperadas = {"start_ip", "end_ip", "country", "country_name",
                                      "asn", "as_name", "as_domain"}
        faltantes_ipinfo = columnas_ipinfo_esperadas - set(df_ipinfo.columns)
        if faltantes_ipinfo:
            raise ValueError(
                f"ERROR: el archivo IPinfo no contiene las columnas esperadas: "
                f"{faltantes_ipinfo}"
            )

        start_clas = df_ipinfo["start_ip"].apply(clasificar_ip)
        end_clas = df_ipinfo["end_ip"].apply(clasificar_ip)
        df_ipinfo["start_ip_int"] = start_clas.apply(lambda t: t[0])
        df_ipinfo["start_version"] = start_clas.apply(lambda t: t[1])
        df_ipinfo["end_ip_int"] = end_clas.apply(lambda t: t[0])
        del start_clas, end_clas

        df_ipinfo_v4 = df_ipinfo[df_ipinfo["start_version"] == 4].copy()
        del df_ipinfo

        df_ipinfo_v4 = df_ipinfo_v4.dropna(subset=["start_ip_int", "end_ip_int"])
        df_ipinfo_v4 = df_ipinfo_v4.sort_values("start_ip_int").reset_index(drop=True)

        # CORRECCIÓN DE DTYPE (no eliminar): tras el dropna() anterior,
        # start_ip_int/end_ip_int YA NO contienen NaN en este
        # subconjunto. Se fuerza int64 explícitamente, ahora que la
        # ausencia de NaN está garantizada.
        df_ipinfo_v4["start_ip_int"] = df_ipinfo_v4["start_ip_int"].astype("int64")
        df_ipinfo_v4["end_ip_int"] = df_ipinfo_v4["end_ip_int"].astype("int64")

        print(f"  Rangos IPv4 disponibles en IPinfo: {len(df_ipinfo_v4):,}")

        ips_unicas = (
            df_logs.loc[df_logs["ip_version"] == 4, ["ip_int"]]
            .drop_duplicates()
            .sort_values("ip_int")
            .reset_index(drop=True)
        )

        # CORRECCIÓN DE DTYPE (no eliminar): 'ip_int' llega aquí ya
        # filtrado a ip_version==4, lo que garantiza ausencia de NaN en
        # ESTE subconjunto. Se fuerza int64 explícitamente para que
        # coincida con el dtype de start_ip_int en el merge_asof.
        ips_unicas["ip_int"] = ips_unicas["ip_int"].astype("int64")
        print(f"  IPs IPv4 únicas a resolver: {len(ips_unicas):,}")

        columnas_geo_ipinfo = {
            "country": "ip_country_code",
            "country_name": "ip_country_name",
            "asn": "ip_asn",
            "as_name": "ip_as_name",
            "as_domain": "ip_as_domain",
        }
        df_ipinfo_v4 = df_ipinfo_v4.rename(columns=columnas_geo_ipinfo)
        columnas_geo_final = list(columnas_geo_ipinfo.values())

        resuelto = pd.merge_asof(
            ips_unicas,
            df_ipinfo_v4[["start_ip_int", "end_ip_int"] + columnas_geo_final],
            left_on="ip_int",
            right_on="start_ip_int",
            direction="backward",
        )
        del df_ipinfo_v4

        dentro_de_rango = resuelto["ip_int"] <= resuelto["end_ip_int"]
        for col in columnas_geo_final:
            resuelto.loc[~dentro_de_rango, col] = np.nan

        ipv4_unicas_resueltas = int(dentro_de_rango.sum())
        ipv4_unicas_no_resueltas = len(resuelto) - ipv4_unicas_resueltas

        resuelto_final = resuelto[["ip_int"] + columnas_geo_final].drop_duplicates(subset="ip_int")
        del resuelto
        df_logs = df_logs.merge(resuelto_final, on="ip_int", how="left")
        del resuelto_final

        # Normalización de mayúsculas del código ISO2 nativo (por
        # seguridad, sin depender de un supuesto silencioso).
        df_logs["ip_country_code"] = df_logs["ip_country_code"].str.upper()

        pct_resolucion = (
            100 * ipv4_unicas_resueltas / len(ips_unicas) if len(ips_unicas) else 0.0
        )

        diagnostico_resolucion = {
            "total_ips": total_ips,
            "total_ipv4": total_ipv4,
            "total_ipv6": total_ipv6,
            "total_invalidas": total_invalidas,
            "ipv4_unicas_resueltas": ipv4_unicas_resueltas,
            "ipv4_unicas_no_resueltas": ipv4_unicas_no_resueltas,
            "pct_resolucion_ipv4": pct_resolucion,
        }

        print(f"  IPs IPv4 únicas resueltas: {ipv4_unicas_resueltas:,} / "
              f"{len(ips_unicas):,} ({pct_resolucion:.2f}%)")
        print("  (No se asume 100% de resolución; se mide realmente)")
        print("  Columnas de IPinfo agregadas con prefijo 'ip_' (no sustituyen "
              "'Country'/'Region'/'City'/'ASN' originales del RBA)")
        print("  'ip_country_code' (ISO2, normalizado a mayúsculas) es la columna "
              "que se usa en country_mismatch — 'ip_country_name' se conserva "
              "solo para lectura humana.\n")

        return df_logs, diagnostico_resolucion

```

### ARCHIVO: fase03_refactor\fase03\ip_utils.py
```python
"""
ip_utils.py
===========
Utilidades PURAS de clasificación de direcciones IP. No tienen estado
compartido entre llamadas, por eso permanecen como funciones de módulo
y NO como métodos de una clase (ver docs/FASE_03_INFORME_TECNICO.md,
sección "Qué NO se convirtió en clase y por qué").
"""
import numpy as np
import pandas as pd
import ipaddress


def clasificar_ip(ip_str):
    """Clasifica una IP y, si es IPv4 válida, la convierte a entero.
    version=4 -> IPv4 (ip_int válido). version=6 -> IPv6 (no se resuelve
    en Fase 03). version=None -> inválida/nula. Nunca lanza excepción."""
    if pd.isna(ip_str):
        return (np.nan, None)
    try:
        ip_obj = ipaddress.ip_address(str(ip_str).strip())
        if isinstance(ip_obj, ipaddress.IPv4Address):
            return (int(ip_obj), 4)
        else:
            return (np.nan, 6)
    except ValueError:
        return (np.nan, None)


def diagnosticar_ipv4_ipv6(serie_ips, etiqueta_poblacion):
    """Diagnóstico IPv4/IPv6/inválidas para CUALQUIER población de IPs,
    etiquetado explícitamente para que el checklist nunca mezcle
    poblaciones distintas sin identificarlas."""
    versiones = serie_ips.apply(lambda x: clasificar_ip(x)[1])
    total = len(versiones)
    total_ipv4 = int((versiones == 4).sum())
    total_ipv6 = int((versiones == 6).sum())
    total_invalidas = int(versiones.isna().sum())

    return {
        "poblacion": etiqueta_poblacion,
        "total_ips": total,
        "total_ipv4": total_ipv4,
        "total_ipv6": total_ipv6,
        "total_invalidas": total_invalidas,
        "pct_ipv4": 100 * total_ipv4 / total if total else 0.0,
        "pct_ipv6": 100 * total_ipv6 / total if total else 0.0,
        "pct_invalidas": 100 * total_invalidas / total if total else 0.0,
    }

```

### ARCHIVO: fase03_refactor\fase03\muestreo.py
```python
"""
muestreo.py
===========
Aísla la decisión de QUÉ usuarios entran al pipeline, separada de QUÉ
se hace una vez que ya fueron elegidos (extracción de historial,
features, etc.).

DÓNDE SE APLICA OCP Y DIP (justificación real, no nominal)
-----------------------------------------------------------
- OCP: agregar una nueva estrategia de muestreo (ej. estratificada por
  presencia de Account Takeover) NO requiere modificar PipelineFase03
  ni ninguna otra clase del pipeline — solo se agrega una clase nueva
  que implementa EstrategiaMuestreo y se inyecta en su lugar.
- DIP: PipelineFase03 depende de la abstracción EstrategiaMuestreo,
  inyectada por constructor. Nunca instancia una estrategia concreta
  internamente (ver pipeline.py).

ETAPA 1 (este archivo, tal como se entrega hoy)
-------------------------------------------------
Solo se implementa MuestreoAleatorioSimple, que reproduce EXACTAMENTE
la lógica de seleccionar_usuarios() en fase03_pipeline_v4.py — cero
cambios metodológicos.

MuestreoEstratificadoPorTarget queda con la interfaz definida pero SIN
IMPLEMENTAR (levanta NotImplementedError), a la espera del diagnóstico
pendiente sobre los usuarios con Account Takeover=True (Etapa 2 del
proyecto). No se debe activar ni se debe especular su lógica interna
todavía.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from collections import Counter

import numpy as np


@dataclass
class ResultadoMuestreo:
    """Resultado de una estrategia de muestreo.

    'origen' es metadato de trazabilidad académica: de dónde vino cada
    usuario ('aleatorio', o en el futuro 'positivo_forzado'). Esto es
    lo que permite documentar honestamente, en la Etapa 2, que la
    prevalencia de la muestra final no representa la prevalencia real
    del RBA completo.

    En la Etapa 1, con MuestreoAleatorioSimple como única estrategia,
    todos los usuarios tienen origen='aleatorio'.
    """
    usuarios: list
    origen: dict = field(default_factory=dict)


class EstrategiaMuestreo(ABC):
    """Contrato: decide QUÉ usuarios entran al pipeline. Nunca decide
    QUÉ VALOR toma una feature — esa frontera es la que separa
    "usar el target para seleccionar la muestra" (válido, si se
    documenta) de "usar el target para construir features" (target
    leakage, prohibido en todos los casos)."""

    @abstractmethod
    def seleccionar(self, contador_usuarios: Counter) -> ResultadoMuestreo:
        ...


class MuestreoAleatorioSimple(EstrategiaMuestreo):
    """Selección ALEATORIA, REPRODUCIBLE, SIN REEMPLAZO de N_USUARIOS
    entre los usuarios con >= MIN_EVENTOS_USUARIO eventos.

    Lógica IDÉNTICA a seleccionar_usuarios() en fase03_pipeline_v4.py.
    Cero cambios metodológicos en esta etapa — es la estrategia que ya
    produjo el resultado real de 2.000 usuarios / 54.742 eventos /
    0 positivos, documentado y explicado en la sesión anterior.
    """

    def __init__(self, config):
        self.config = config

    def seleccionar(self, contador_usuarios):
        config = self.config
        print("=" * 60)
        print("[3/8] Seleccionando usuarios (muestreo aleatorio simple)...")
        print("=" * 60)

        poblacion_elegible = [
            uid for uid, freq in contador_usuarios.items()
            if freq >= config.MIN_EVENTOS_USUARIO
        ]
        poblacion_elegible.sort()

        print(f"  Usuarios con >= {config.MIN_EVENTOS_USUARIO} eventos: "
              f"{len(poblacion_elegible):,}")

        if len(poblacion_elegible) < config.N_USUARIOS:
            raise ValueError(
                "La población elegible es menor que N_USUARIOS. "
                "Revisa MIN_EVENTOS_USUARIO o el archivo de origen."
            )

        rng = np.random.default_rng(config.RANDOM_STATE)
        usuarios_seleccionados = rng.choice(
            poblacion_elegible, size=config.N_USUARIOS, replace=False
        )
        usuarios_seleccionados = sorted(int(u) for u in usuarios_seleccionados)

        if len(set(usuarios_seleccionados)) != config.N_USUARIOS:
            raise RuntimeError(
                "ERROR CRÍTICO: la selección de usuarios no produjo exactamente "
                f"{config.N_USUARIOS} usuarios únicos. Selección abortada."
            )
        for uid in usuarios_seleccionados:
            if contador_usuarios[uid] < config.MIN_EVENTOS_USUARIO:
                raise RuntimeError(
                    f"ERROR CRÍTICO: el usuario {uid} fue seleccionado pero no "
                    f"cumple MIN_EVENTOS_USUARIO. Selección abortada."
                )

        print(f"  Usuarios seleccionados: {len(usuarios_seleccionados):,} "
              f"(RANDOM_STATE={config.RANDOM_STATE})")
        print("  [OK] Verificado: exactamente N_USUARIOS únicos, todos con "
              "el mínimo de eventos requerido.\n")

        origen = {uid: "aleatorio" for uid in usuarios_seleccionados}
        return ResultadoMuestreo(usuarios=usuarios_seleccionados, origen=origen)


class MuestreoEstratificadoPorTarget(EstrategiaMuestreo):
    """PENDIENTE DE IMPLEMENTACIÓN — Etapa 2 del proyecto.

    Objetivo futuro (NO implementado todavía): garantizar que la
    muestra de N_USUARIOS incluya deliberadamente a los usuarios con
    >=1 evento 'Is Account Takeover'=True (diseño caso-control),
    documentando el sesgo de prevalencia que esto introduce respecto
    al RBA completo.

    Esta clase existe HOY únicamente para fijar el contrato de la
    interfaz (mismo método seleccionar(), misma firma de retorno
    ResultadoMuestreo) y así demostrar que PipelineFase03 no necesitará
    cambios cuando se implemente — solo se inyectará esta clase en vez
    de MuestreoAleatorioSimple.

    Precondición pendiente antes de escribir su lógica interna:
    ejecutar el diagnóstico de cuántos de los usuarios con Account
    Takeover=True cumplen MIN_EVENTOS_USUARIO >= 15, y cómo se
    distribuyen los eventos positivos entre ellos (Etapa 2).

    Nota metodológica (para cuando se implemente): usar el target
    aquí NO constituye target leakage — decide qué FILAS/USUARIOS
    entran al dataset, nunca qué VALOR toma una feature. Ver
    docs/FASE_03_INFORME_TECNICO.md, sección "Prevención de target
    leakage", para la justificación completa y la distinción formal
    entre ambos usos del target.
    """

    def __init__(self, config):
        self.config = config

    def seleccionar(self, contador_usuarios):
        raise NotImplementedError(
            "MuestreoEstratificadoPorTarget aún no está implementado. "
            "Pendiente del diagnóstico de la Etapa 2: cuántos usuarios con "
            "Is Account Takeover=True cumplen MIN_EVENTOS_USUARIO>=15, y "
            "cómo se distribuyen sus eventos positivos. "
            "Usa MuestreoAleatorioSimple mientras tanto."
        )

```

### ARCHIVO: fase03_refactor\fase03\pipeline.py
```python
"""
pipeline.py
===========
Orquestador de las 8 etapas de la Fase 03.

DIP EN ACCIÓN
-------------
PipelineFase03 recibe la estrategia de muestreo POR CONSTRUCTOR
(inyección de dependencia) — nunca instancia una estrategia concreta
internamente. Esto permite sustituir MuestreoAleatorioSimple por
MuestreoEstratificadoPorTarget (Etapa 2) sin modificar ni una línea
de esta clase.

REGLA DE MEMORIA
-----------------
self solo guarda config y la estrategia de muestreo (ambos livianos).
Ningún DataFrame grande ni Counter se guarda como atributo de
instancia — todos son variables locales de ejecutar(), liberadas
explícitamente con del + gc.collect() en los mismos puntos donde ya
se liberaban en fase03_pipeline_v4.py.

BARRERA ESTRUCTURAL CONTRA TARGET LEAKAGE
-------------------------------------------
'Is Account Takeover' se retira FÍSICAMENTE del DataFrame
(df.pop(...)) inmediatamente después de la resolución IP y ANTES de
que cualquier función de features.py reciba el DataFrame. Se
reincorpora únicamente después de que todas las features ya fueron
construidas, justo antes de validar/exportar. Mientras la columna no
existe en el DataFrame, es físicamente imposible que una función de
features la lea — incluso por un descuido futuro de quien edite
features.py, ya que un KeyError sería inmediato si lo intentara.
"""
import gc

from .rba_reader import AnalizadorRBA
from .empleados import GeneradorEmpleados
from .ip_resolver import ResolutorIPinfo
from .features import (
    crear_features_temporales,
    crear_feature_impossible_travel,
    crear_feature_turnos,
    crear_features_negocio,
)
from .validacion import validar_calidad_bloqueante
from .diagnostico import generar_metricas_diagnosticas, imprimir_checklist_final
from .exportacion import exportar_dataset_final


class PipelineFase03:
    def __init__(self, config, estrategia_muestreo):
        self.config = config
        self.estrategia_muestreo = estrategia_muestreo

    def ejecutar(self):
        config = self.config

        # --- [1-2/8] Análisis del RBA completo por chunks ---
        analizador = AnalizadorRBA(config)
        contador_usuarios, diagnostico_global = analizador.primera_pasada()

        # --- [3/8] Selección de usuarios (estrategia inyectada) ---
        resultado_muestreo = self.estrategia_muestreo.seleccionar(contador_usuarios)
        usuarios_seleccionados = resultado_muestreo.usuarios
        del contador_usuarios
        gc.collect()

        # --- [4/8] Extracción del historial completo ---
        df_logs, diagnostico_subconjunto = analizador.segunda_pasada(usuarios_seleccionados)

        # --- [5/8] Maestro sintético de empleados ---
        generador_empleados = GeneradorEmpleados(config)
        df_empleados = generador_empleados.generar(usuarios_seleccionados)

        df_integrado = df_logs.merge(df_empleados, on="User ID", how="inner")
        del df_logs, df_empleados
        gc.collect()

        # --- [6/8] Resolución IP (incluye fix de dtype de merge_asof) ---
        resolutor_ip = ResolutorIPinfo(config)
        df_integrado, diagnostico_resolucion = resolutor_ip.resolver(df_integrado)

        # --- BARRERA ESTRUCTURAL ANTI-LEAKAGE ---
        if "Is Account Takeover" not in df_integrado.columns:
            raise RuntimeError(
                "ERROR CRÍTICO: 'Is Account Takeover' no está presente antes "
                "de retirarla para la construcción de features. Esto no "
                "debería ocurrir — revisa la extracción del RBA."
            )
        serie_target = df_integrado.pop("Is Account Takeover")

        # --- [7/8] Ingeniería de características (target físicamente ausente) ---
        df_integrado, n_login_desconocidos = crear_features_temporales(df_integrado, config)
        df_integrado, diagnostico_centroides = crear_feature_impossible_travel(df_integrado, config)
        df_integrado = crear_feature_turnos(df_integrado)
        df_integrado = crear_features_negocio(df_integrado)

        # --- Reincorporación del target (solo ahora) ---
        df_integrado["Is Account Takeover"] = serie_target
        del serie_target

        # --- [8/8] Validación bloqueante + exportación + diagnóstico ---
        validar_calidad_bloqueante(df_integrado, usuarios_seleccionados, config)

        df_final = exportar_dataset_final(df_integrado, config)

        metricas = generar_metricas_diagnosticas(
            df_integrado, usuarios_seleccionados, diagnostico_global,
            diagnostico_subconjunto, diagnostico_resolucion,
            diagnostico_centroides, n_login_desconocidos, config,
        )

        imprimir_checklist_final(df_final, metricas, config)

        return df_final

```

### ARCHIVO: fase03_refactor\fase03\rba_reader.py
```python
"""
rba_reader.py
=============
Lectura del RBA Dataset (~33M+ filas / ~9 GB) mediante procesamiento
por chunks, en dos pasadas independientes (README, secciones 7-9,
45-46).

  1) primera_pasada(): recorre el archivo COMPLETO una sola vez para
     contar eventos por usuario (Counter) y diagnosticar IPv4/IPv6 a
     nivel global. Nunca carga el archivo completo en memoria.
  2) segunda_pasada(usuarios_seleccionados): recorre el archivo de
     nuevo, filtrando por isin() para retener únicamente el historial
     completo de los usuarios ya seleccionados.

POR QUÉ ES UNA CLASE (justificación real, no nominal)
------------------------------------------------------
Ambos métodos comparten la misma configuración (ruta del RBA, tamaños
de chunk, columnas obligatorias) a través de DOS invocaciones
secuenciales sobre el mismo objeto durante una sola corrida del
pipeline. Es genuinamente distinto de envolver una función de un solo
método en una clase (lo cual SÍ evitamos en features.py/validacion.py
tras la revisión crítica) — aquí hay estado compartido real entre
llamadas.

REGLA DE MEMORIA (obligatoria tras la revisión crítica)
--------------------------------------------------------
Esta clase NUNCA almacena el Counter ni los DataFrames grandes como
atributos de self. Solo self.config (liviano) vive en la instancia.
El Counter (puede tener millones de claves) y los DataFrames (pueden
pesar varios GB) se devuelven como valores de retorno; liberarlos con
del + gc.collect() sigue siendo responsabilidad del orquestador
(PipelineFase03), exactamente en los mismos puntos donde ya se
liberaban en fase03_pipeline_v4.py.
"""
import time
from collections import Counter

import pandas as pd

from .ip_utils import clasificar_ip, diagnosticar_ipv4_ipv6


class AnalizadorRBA:
    def __init__(self, config):
        self.config = config

    def _validar_columnas(self):
        """Valida el encabezado REAL del CSV (nrows=0) antes de leer
        nada. Método privado: no forma parte del contrato público de
        la clase, solo lo usa primera_pasada() como paso previo."""
        config = self.config
        print("  Validando encabezado real del archivo RBA...")
        encabezado_real = set(pd.read_csv(config.RBA_PATH, nrows=0).columns)
        faltantes = [c for c in config.COLUMNAS_RBA_OBLIGATORIAS if c not in encabezado_real]

        if faltantes:
            raise ValueError(
                "ERROR DE VALIDACIÓN DE ENCABEZADO — el archivo RBA no contiene "
                f"las columnas obligatorias: {faltantes}.\n"
                f"Columnas encontradas en el archivo: {sorted(encabezado_real)}\n"
                "El pipeline NO renombra columnas de forma silenciosa."
            )

        print(f"  Encabezado validado: las {len(config.COLUMNAS_RBA_OBLIGATORIAS)} "
              "columnas obligatorias están presentes.\n")
        return True

    def primera_pasada(self):
        """Primera pasada COMPLETA sobre el RBA (33M+ filas) por
        chunks. Devuelve (Counter de eventos por usuario, diagnóstico
        global IPv4/IPv6)."""
        config = self.config
        print("=" * 60)
        print("[2/8] Analizando dataset RBA (primera pasada, por chunks)...")
        print("=" * 60)

        self._validar_columnas()

        contador_usuarios = Counter()
        acumulador_global = {"total": 0, "ipv4": 0, "ipv6": 0, "invalidas": 0}

        t0 = time.time()
        n_chunks = 0

        reader = pd.read_csv(
            config.RBA_PATH,
            usecols=["User ID", "IP Address"],
            chunksize=config.CHUNKSIZE_PASADA_1,
            dtype={"User ID": "int64"},
        )

        for chunk in reader:
            n_chunks += 1
            contador_usuarios.update(chunk["User ID"].values)

            versiones = chunk["IP Address"].apply(lambda x: clasificar_ip(x)[1])
            acumulador_global["total"] += len(versiones)
            acumulador_global["ipv4"] += int((versiones == 4).sum())
            acumulador_global["ipv6"] += int((versiones == 6).sum())
            acumulador_global["invalidas"] += int(versiones.isna().sum())

            if n_chunks % 5 == 0:
                print(f"    ... {n_chunks} chunks procesados "
                      f"({acumulador_global['total']:,} filas acumuladas)")

        duracion = time.time() - t0
        total = acumulador_global["total"]

        diagnostico_global = {
            "poblacion": "RBA GLOBAL (33M+)",
            "total_ips": total,
            "total_ipv4": acumulador_global["ipv4"],
            "total_ipv6": acumulador_global["ipv6"],
            "total_invalidas": acumulador_global["invalidas"],
            "pct_ipv4": 100 * acumulador_global["ipv4"] / total if total else 0.0,
            "pct_ipv6": 100 * acumulador_global["ipv6"] / total if total else 0.0,
            "pct_invalidas": 100 * acumulador_global["invalidas"] / total if total else 0.0,
        }

        print(f"\n  Chunks procesados: {n_chunks}")
        print(f"  Usuarios únicos detectados: {len(contador_usuarios):,}")
        print(f"  [POBLACIÓN GLOBAL] IPv4: {diagnostico_global['total_ipv4']:,} "
              f"({diagnostico_global['pct_ipv4']:.2f}%)")
        print(f"  [POBLACIÓN GLOBAL] IPv6: {diagnostico_global['total_ipv6']:,} "
              f"({diagnostico_global['pct_ipv6']:.2f}%)")
        print(f"  [POBLACIÓN GLOBAL] Inválidas: {diagnostico_global['total_invalidas']:,} "
              f"({diagnostico_global['pct_invalidas']:.2f}%)")
        print(f"  Tiempo primera pasada: {duracion:.1f}s\n")

        return contador_usuarios, diagnostico_global

    def segunda_pasada(self, usuarios_seleccionados):
        """Segunda pasada por chunks: aísla TODO el historial de los
        usuarios seleccionados (no son N_USUARIOS filas, README
        Sección 8)."""
        config = self.config
        print("=" * 60)
        print("[4/8] Extrayendo historial completo de los usuarios seleccionados...")
        print("=" * 60)

        set_usuarios = set(usuarios_seleccionados)
        columnas = config.COLUMNAS_RBA_OBLIGATORIAS

        fragmentos = []
        n_chunks = 0
        t0 = time.time()

        reader = pd.read_csv(
            config.RBA_PATH,
            usecols=columnas,
            chunksize=config.CHUNKSIZE_PASADA_2,
            dtype={"User ID": "int64"},
        )

        for chunk in reader:
            n_chunks += 1
            filtrado = chunk[chunk["User ID"].isin(set_usuarios)]
            if not filtrado.empty:
                fragmentos.append(filtrado)

            if n_chunks % 5 == 0:
                filas_acum = sum(len(f) for f in fragmentos)
                print(f"    ... {n_chunks} chunks leídos, "
                      f"{filas_acum:,} filas retenidas hasta ahora")

        if not fragmentos:
            raise RuntimeError(
                "ERROR CRÍTICO: la segunda pasada no encontró NINGÚN registro "
                "para los usuarios seleccionados. Revisa integridad del archivo."
            )

        df_2000 = pd.concat(fragmentos, ignore_index=True)
        del fragmentos
        duracion = time.time() - t0

        diagnostico_subconjunto = diagnosticar_ipv4_ipv6(
            df_2000["IP Address"], etiqueta_poblacion="SUBCONJUNTO usuarios seleccionados"
        )

        df_2000.to_csv(config.OUT_RBA_2000, index=False)

        print(f"\n  Filas totales extraídas: {len(df_2000):,}")
        print(f"  Usuarios distintos en el resultado: "
              f"{df_2000['User ID'].nunique():,}")
        print(f"  [SUBCONJUNTO] IPv4: {diagnostico_subconjunto['total_ipv4']:,} "
              f"({diagnostico_subconjunto['pct_ipv4']:.2f}%)")
        print(f"  [SUBCONJUNTO] IPv6: {diagnostico_subconjunto['total_ipv6']:,} "
              f"({diagnostico_subconjunto['pct_ipv6']:.2f}%)")
        print(f"  Archivo generado: {config.OUT_RBA_2000}")
        print(f"  Tiempo segunda pasada: {duracion:.1f}s\n")

        return df_2000, diagnostico_subconjunto

```

### ARCHIVO: fase03_refactor\fase03\timestamp_utils.py
```python
"""
timestamp_utils.py
===================
Conversión defensiva de 'Login Timestamp' (entero Unix de 64 bits con
unidad no especificada por la documentación oficial del RBA Dataset).
Funciones puras, sin estado compartido -> permanecen como funciones de
módulo, no como clase.
"""
import pandas as pd


def inferir_unidad_timestamp(serie_numerica):
    """
    Infiere la unidad de un timestamp Unix de 64 bits a partir del
    orden de magnitud de los valores (NO se asume 's' a ciegas, porque
    la documentación oficial del RBA Dataset confirma que la columna es
    un entero de 64 bits pero no especifica la unidad).

    Heurística estándar por número de dígitos de la parte entera:
        ~10 dígitos -> segundos       (hasta el año ~2286)
        ~13 dígitos -> milisegundos
        ~16 dígitos -> microsegundos
        ~19 dígitos -> nanosegundos

    Devuelve (unidad, mediana_de_magnitud) para que quede trazable en
    los logs qué se detectó y por qué.
    """
    valores_validos = pd.to_numeric(serie_numerica, errors="coerce").dropna()
    if valores_validos.empty:
        return "s", None

    mediana = valores_validos.abs().median()
    orden_magnitud = len(str(int(mediana))) if mediana > 0 else 1

    if orden_magnitud <= 10:
        unidad = "s"
    elif orden_magnitud <= 13:
        unidad = "ms"
    elif orden_magnitud <= 16:
        unidad = "us"
    else:
        unidad = "ns"

    return unidad, mediana


def convertir_login_timestamp(serie_original, ventana_fechas_conocida=None):
    """
    Convierte 'Login Timestamp' a datetime64[ns] de forma DEFENSIVA:

    1) Caso esperado (documentación oficial): la columna es un ENTERO
       de 64 bits. Se infiere la unidad real (segundos/ms/us/ns) por
       orden de magnitud — nunca se asume 'unit=s' sin verificar.
    2) Salvaguarda: si la mayoría de los valores NO son numéricos
       (columna en texto, p. ej. por un mirror de Kaggle distinto), se
       cambia de estrategia y se parsea como texto de fecha/hora en vez
       de fallar o corromper silenciosamente todos los deltas de tiempo.

    Adicionalmente se ejecuta una verificación de cordura (no
    bloqueante) contra la ventana de recolección conocida del dataset
    original, para detectar si la unidad inferida produjo fechas
    absurdas.
    """
    numerico = pd.to_numeric(serie_original, errors="coerce")

    no_nulos_original = serie_original.notna()
    total_no_nulos = int(no_nulos_original.sum())
    if total_no_nulos == 0:
        proporcion_numerica = 0.0
    else:
        convertidos_ok = (numerico.notna() & no_nulos_original).sum()
        proporcion_numerica = convertidos_ok / total_no_nulos

    if proporcion_numerica >= 0.95:
        unidad, mediana = inferir_unidad_timestamp(serie_original)
        print(f"  'Login Timestamp' detectado como ENTERO (Unix epoch de 64 bits). "
              f"Unidad inferida: '{unidad}' (mediana de magnitud: {mediana}).")
        convertido = pd.to_datetime(numerico, unit=unidad, errors="coerce")
    else:
        print("  [ATENCIÓN] 'Login Timestamp' NO parece numérico en este archivo "
              "(contradice la especificación oficial del RBA Dataset, que lo "
              "define como entero de 64 bits). Se intentará parsear como texto "
              "de fecha/hora en su lugar.")
        convertido = pd.to_datetime(serie_original, errors="coerce")

    fecha_min = convertido.min()
    fecha_max = convertido.max()
    print(f"  Rango de fechas resultante: {fecha_min} -> {fecha_max}")

    if ventana_fechas_conocida and pd.notna(fecha_min) and pd.notna(fecha_max):
        limite_inf = pd.Timestamp(ventana_fechas_conocida[0])
        limite_sup = pd.Timestamp(ventana_fechas_conocida[1])
        fuera_de_ventana = (fecha_min < limite_inf) or (fecha_max > limite_sup)
        if fuera_de_ventana:
            print(
                "  [ATENCIÓN] El rango de fechas resultante cae FUERA de la "
                f"ventana de recolección conocida del RBA Dataset "
                f"({ventana_fechas_conocida[0]} a {ventana_fechas_conocida[1]}). "
                "Esto puede indicar que la unidad inferida es incorrecta. "
                "Verifica manualmente una muestra de valores crudos de "
                "'Login Timestamp' antes de confiar en los resultados."
            )
        else:
            print("  [OK] El rango de fechas resultante es consistente con la "
                  "ventana de recolección conocida del dataset.")

    n_no_convertibles = int(convertido.isna().sum() - serie_original.isna().sum())
    if n_no_convertibles > 0:
        print(f"  [ATENCIÓN] {n_no_convertibles:,} valores de 'Login Timestamp' "
              "no se pudieron convertir y quedaron como NaT.")

    return convertido

```

### ARCHIVO: fase03_refactor\fase03\validacion.py
```python
"""
validacion.py
=============
Validaciones bloqueantes que DETIENEN la ejecución si fallan.

Se mantiene como FUNCIÓN, no como clase: no tiene estado propio más
allá de 'config' y un único método público — envolverla en una clase
habría sido cumplimiento cosmético, no una necesidad arquitectónica
(mismo criterio aplicado en features.py tras la revisión crítica).
"""
import pandas as pd


def validar_calidad_bloqueante(df, usuarios_seleccionados, config):
    """Validaciones CRÍTICAS que DETIENEN la ejecución si fallan."""
    print("=" * 60)
    print("[8/8] Ejecutando validaciones BLOQUEANTES...")
    print("=" * 60)

    errores = []

    if len(set(usuarios_seleccionados)) != config.N_USUARIOS:
        errores.append(
            f"Se esperaban {config.N_USUARIOS} usuarios únicos, "
            f"hay {len(set(usuarios_seleccionados))}."
        )

    usuarios_en_df = set(df["User ID"].unique())
    faltan_en_df = set(usuarios_seleccionados) - usuarios_en_df
    if faltan_en_df:
        errores.append(
            f"{len(faltan_en_df)} usuarios seleccionados no aparecen en el "
            "dataset integrado final (integridad referencial < 100%)."
        )

    conteo_final = df["User ID"].value_counts()
    insuficientes = conteo_final[conteo_final < config.MIN_EVENTOS_USUARIO]
    if len(insuficientes) > 0:
        errores.append(
            f"{len(insuficientes)} usuarios tienen menos de "
            f"{config.MIN_EVENTOS_USUARIO} eventos en el dataset final."
        )

    if not pd.api.types.is_datetime64_any_dtype(df["Login Timestamp"]):
        errores.append("'Login Timestamp' no quedó convertido a datetime64.")

    orden_correcto = df.groupby("User ID")["Login Timestamp"].apply(
        lambda s: s.is_monotonic_increasing
    ).all()
    if not orden_correcto:
        errores.append(
            "El dataset no está correctamente ordenado por "
            "['User ID', 'Login Timestamp'] ascendente en todos los grupos."
        )

    columnas_obligatorias_salida = [
        "User ID", "Login Timestamp", "Is Account Takeover",
        "failed_attempts_15min", "failed_attempts_1h",
        "has_previous_login",
        "impossible_travel", "is_outside_shift",
        "country_mismatch", "inactive_account_success",
    ]
    faltantes_salida = [c for c in columnas_obligatorias_salida if c not in df.columns]
    if faltantes_salida:
        errores.append(f"Faltan columnas obligatorias de salida: {faltantes_salida}")

    if "Is Account Takeover" not in df.columns:
        errores.append("'Is Account Takeover' (Ground Truth) no está presente.")
    elif df["Is Account Takeover"].isna().all():
        errores.append("'Is Account Takeover' está completamente vacío.")

    fecha_min = df["Login Timestamp"].min()
    fecha_max = df["Login Timestamp"].max()
    if pd.notna(fecha_min) and fecha_min.year < 1990:
        errores.append(
            f"'Login Timestamp' produjo fechas implausibles (mínimo: "
            f"{fecha_min}). Esto sugiere que la unidad del timestamp se "
            "infirió incorrectamente."
        )

    if "has_previous_login" in df.columns:
        primer_evento = df["has_previous_login"] == 0
        fuga_distancia = primer_evento & df["distance_previous_km"].notna()
        fuga_velocidad = primer_evento & df["required_speed_kmh"].notna()
        if fuga_distancia.any() or fuga_velocidad.any():
            errores.append(
                "Se encontraron valores NO nulos de 'distance_previous_km' o "
                "'required_speed_kmh' en registros con has_previous_login=0 "
                "(primer evento del usuario). Esto viola la regla de missing "
                "semántico: la ausencia de historial debe producir NaN, "
                "nunca un valor calculado."
            )

    if "country_mismatch" in df.columns and "ip_country_code" in df.columns:
        ip_no_resuelta = df["ip_country_code"].isna()
        mismatch_deberia_ser_nan_pero_no_lo_es = (
            ip_no_resuelta & df["country_mismatch"].notna()
        )
        if mismatch_deberia_ser_nan_pero_no_lo_es.any():
            errores.append(
                "'country_mismatch' tiene valores no nulos en registros donde "
                "'ip_country_code' es NaN (IP no resuelta). Sin país de IP "
                "conocido, el mismatch debe ser NaN."
            )

    if errores:
        mensaje = (
            "VALIDACIÓN BLOQUEANTE FALLIDA — el dataset final NO se exportará.\n"
            "Errores encontrados:\n" + "\n".join(f"  - {e}" for e in errores)
        )
        raise RuntimeError(mensaje)

    print("  [OK] Todas las validaciones bloqueantes pasaron correctamente.\n")
    return True

```

### ARCHIVO: fase03_refactor\fase03\__init__.py
```python
"""
Paquete fase03 — Preparación de Datos (CRISP-DM) para el proyecto de
detección predictiva de accesos anómalos.

Arquitectura modular, Etapa 1: refactor puro sobre fase03_pipeline_v4.py,
sin cambios metodológicos. Ver docs/FASE_03_INFORME_TECNICO.md para el
detalle de cada módulo y las decisiones de diseño.
"""

```

### ARCHIVO: fase03_refactor\tests\comparar_pipelines_colab.py
```python
"""
comparar_pipelines_colab.py
===========================
Herramienta de VERIFICACIÓN (no forma parte de la arquitectura de
fase03/ — es un script de diagnóstico independiente, pensado para
correr una sola vez en Colab con los archivos reales).

QUÉ HACE
--------
Toma tu rba_2000_users.csv real, genera empleados + resuelve IP +
construye features TANTO con el pipeline monolítico
(tests/legacy/fase03_pipeline_v4.py) COMO con la arquitectura modular
(fase03/), y compara ambos resultados en 7 dimensiones distintas —
no solo un booleano de equals():

  1. Forma (filas, columnas)
  2. Nombres y ORDEN de columnas
  3. Dtypes por columna
  4. Igualdad exacta de valores (pd.testing.assert_frame_equal)
  5. Conteo de nulos por columna
  6. Distribución de cada feature (describe() para numéricas,
     value_counts() para binarias/categóricas)
  7. Distribución del target (Is Account Takeover)

Además, compara ambos resultados contra tu empleados.csv YA EXISTENTE
(el de tu corrida real anterior), para detectar si algo cambió incluso
antes de comparar monolito vs modular (deriva de entorno/versión de
librerías entre corridas).

CÓMO SE EJECUTA (ver instrucciones completas en el mensaje de Claude)
----------------------------------------------------------------------
python comparar_pipelines_colab.py \
    --rba-2000 /ruta/a/rba_2000_users.csv \
    --ipinfo /ruta/a/country_asn.csv \
    --empleados-existente /ruta/a/empleados.csv \
    --legacy-script /ruta/a/tests/legacy/fase03_pipeline_v4.py \
    --fase03-path /ruta/a/fase03_refactor

Al finalizar imprime un REPORTE FINAL con veredicto explícito
(EQUIVALENTE / NO EQUIVALENTE) y el detalle exacto de cualquier
diferencia encontrada. Copia esa salida completa de vuelta a Claude.
"""
import argparse
import importlib.util
import sys

import numpy as np
import pandas as pd


def cargar_modulo_legacy(ruta_script):
    spec = importlib.util.spec_from_file_location("fase03_pipeline_v4_legacy", ruta_script)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


def separador(titulo):
    print("\n" + "=" * 70)
    print(titulo)
    print("=" * 70)


def comparar_forma(df_legacy, df_modular, reporte):
    separador("1. FORMA (filas, columnas)")
    ok = df_legacy.shape == df_modular.shape
    print(f"  Legacy:  {df_legacy.shape}")
    print(f"  Modular: {df_modular.shape}")
    print(f"  {'[OK]' if ok else '[DIFERENTE]'} misma forma: {ok}")
    reporte["forma_identica"] = ok
    return ok


def comparar_columnas(df_legacy, df_modular, reporte):
    separador("2. NOMBRES Y ORDEN DE COLUMNAS")
    cols_legacy = list(df_legacy.columns)
    cols_modular = list(df_modular.columns)
    ok = cols_legacy == cols_modular
    if ok:
        print(f"  [OK] {len(cols_legacy)} columnas, mismo nombre y mismo orden.")
    else:
        solo_legacy = [c for c in cols_legacy if c not in cols_modular]
        solo_modular = [c for c in cols_modular if c not in cols_legacy]
        print(f"  [DIFERENTE] Columnas solo en legacy: {solo_legacy}")
        print(f"  [DIFERENTE] Columnas solo en modular: {solo_modular}")
        if set(cols_legacy) == set(cols_modular) and cols_legacy != cols_modular:
            print("  [ATENCIÓN] Mismas columnas mismo set, pero DISTINTO ORDEN.")
    reporte["columnas_identicas"] = ok
    return ok


def comparar_dtypes(df_legacy, df_modular, reporte):
    separador("3. DTYPES POR COLUMNA")
    columnas_comunes = [c for c in df_legacy.columns if c in df_modular.columns]
    diferencias = []
    for col in columnas_comunes:
        dt_l, dt_m = df_legacy[col].dtype, df_modular[col].dtype
        if dt_l != dt_m:
            diferencias.append((col, dt_l, dt_m))
    if not diferencias:
        print(f"  [OK] Los {len(columnas_comunes)} dtypes coinciden exactamente.")
    else:
        print(f"  [DIFERENTE] {len(diferencias)} columnas con dtype distinto:")
        for col, dt_l, dt_m in diferencias:
            print(f"    - {col}: legacy={dt_l}  modular={dt_m}")
    reporte["dtypes_identicos"] = not diferencias
    reporte["dtypes_diferencias"] = diferencias
    return not diferencias


def comparar_valores_exactos(df_legacy, df_modular, reporte):
    separador("4. IGUALDAD EXACTA DE VALORES (pd.testing.assert_frame_equal)")
    try:
        pd.testing.assert_frame_equal(
            df_legacy.reset_index(drop=True),
            df_modular.reset_index(drop=True),
            check_exact=True,
            check_dtype=True,
        )
        print("  [OK] assert_frame_equal PASÓ — valores idénticos fila por fila, "
              "columna por columna, con los mismos dtypes.")
        reporte["valores_identicos"] = True
    except AssertionError as e:
        print("  [DIFERENTE] assert_frame_equal FALLÓ. Detalle:")
        print(str(e))
        reporte["valores_identicos"] = False
        reporte["detalle_assert_frame_equal"] = str(e)
    return reporte["valores_identicos"]


def comparar_nulos(df_legacy, df_modular, reporte):
    separador("5. CONTEO DE NULOS POR COLUMNA")
    columnas_comunes = [c for c in df_legacy.columns if c in df_modular.columns]
    nulos_legacy = df_legacy[columnas_comunes].isna().sum()
    nulos_modular = df_modular[columnas_comunes].isna().sum()
    tabla = pd.DataFrame({"legacy": nulos_legacy, "modular": nulos_modular})
    tabla["diferencia"] = tabla["legacy"] - tabla["modular"]
    diferencias = tabla[tabla["diferencia"] != 0]
    if diferencias.empty:
        print("  [OK] Conteo de nulos idéntico en todas las columnas.")
    else:
        print("  [DIFERENTE] Columnas con distinto conteo de nulos:")
        print(diferencias.to_string())
    reporte["nulos_identicos"] = diferencias.empty
    return diferencias.empty


def comparar_distribuciones(df_legacy, df_modular, reporte):
    separador("6. DISTRIBUCIÓN DE FEATURES")
    columnas_features = [
        "failed_attempts_15min", "failed_attempts_1h", "has_previous_login",
        "distance_previous_km", "required_speed_kmh", "impossible_travel",
        "is_outside_shift", "country_mismatch", "inactive_account_success",
    ]
    columnas_features = [c for c in columnas_features if c in df_legacy.columns and c in df_modular.columns]
    todas_iguales = True
    for col in columnas_features:
        desc_legacy = df_legacy[col].describe()
        desc_modular = df_modular[col].describe()
        diff = (desc_legacy - desc_modular).abs()
        max_diff = diff.max() if not diff.empty else 0
        iguales = pd.isna(max_diff) or max_diff < 1e-9
        estado = "[OK]" if iguales else "[DIFERENTE]"
        print(f"  {estado} {col}: max diff en describe() = {max_diff}")
        if not iguales:
            todas_iguales = False
            print(f"      legacy:  {desc_legacy.to_dict()}")
            print(f"      modular: {desc_modular.to_dict()}")
    reporte["distribuciones_identicas"] = todas_iguales
    return todas_iguales


def comparar_target(df_legacy, df_modular, reporte):
    separador("7. DISTRIBUCIÓN DEL TARGET (Is Account Takeover)")
    vc_legacy = df_legacy["Is Account Takeover"].value_counts(dropna=False).sort_index()
    vc_modular = df_modular["Is Account Takeover"].value_counts(dropna=False).sort_index()
    ok = vc_legacy.equals(vc_modular)
    print(f"  Legacy:\n{vc_legacy.to_string()}")
    print(f"  Modular:\n{vc_modular.to_string()}")
    print(f"  {'[OK]' if ok else '[DIFERENTE]'} distribución del target idéntica: {ok}")
    reporte["target_identico"] = ok
    return ok


def comparar_contra_empleados_existente(ruta_empleados_modular_csv, ruta_empleados_existente, reporte):
    """IMPORTANTE: compara CSV contra CSV (ambos releídos desde disco),
    nunca un DataFrame en memoria contra uno releído. Comparar en-memoria
    vs. releído genera falsos positivos de diferencia de dtype en
    columnas de fecha (Fecha_Ingreso pasa de datetime.date en memoria a
    string tras el round-trip por CSV) — eso NO es una diferencia real
    del refactor, es un artefacto de serialización."""
    separador("EXTRA — Comparación contra tu empleados.csv YA EXISTENTE (corrida real anterior)")
    try:
        df_existente = pd.read_csv(ruta_empleados_existente)
    except FileNotFoundError:
        print(f"  [OMITIDO] No se encontró {ruta_empleados_existente} — se omite esta comparación extra.")
        reporte["coincide_con_empleados_historico"] = None
        return None

    df_modular_releido = pd.read_csv(ruta_empleados_modular_csv)

    try:
        pd.testing.assert_frame_equal(
            df_existente.reset_index(drop=True),
            df_modular_releido.reset_index(drop=True),
            check_exact=True,
        )
        print("  [OK] El empleados.csv regenerado HOY (modular) es IDÉNTICO al que ya "
              "tenías guardado de tu corrida real anterior. No hay deriva de entorno "
              "ni de versión de librerías entre corridas.")
        reporte["coincide_con_empleados_historico"] = True
    except AssertionError as e:
        print("  [ATENCIÓN] El empleados.csv regenerado HOY difiere del que ya tenías "
              "guardado. Esto NO necesariamente es un bug del refactor — puede indicar "
              "que Faker/numpy cambiaron de versión entre tu corrida original y hoy. "
              "Detalle:")
        print(str(e))
        reporte["coincide_con_empleados_historico"] = False
    return reporte["coincide_con_empleados_historico"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rba-2000", required=True, help="Ruta a rba_2000_users.csv")
    parser.add_argument("--ipinfo", required=True, help="Ruta al catálogo IPinfo (country_asn.csv)")
    parser.add_argument("--empleados-existente", required=False, default=None,
                         help="Ruta a tu empleados.csv ya generado (opcional, comparación extra)")
    parser.add_argument("--legacy-script", required=True,
                         help="Ruta a tests/legacy/fase03_pipeline_v4.py")
    parser.add_argument("--fase03-path", required=True,
                         help="Ruta a la carpeta que contiene el paquete fase03/ (para importarlo)")
    parser.add_argument("--out-dir", default="/content/comparacion_tmp",
                         help="Carpeta de trabajo para archivos intermedios")
    args = parser.parse_args()

    sys.path.insert(0, args.fase03_path)
    from fase03.config import ConfiguracionPipeline
    from fase03.empleados import GeneradorEmpleados
    from fase03.ip_resolver import ResolutorIPinfo
    from fase03.features import (
        crear_features_temporales,
        crear_feature_impossible_travel,
        crear_feature_turnos,
        crear_features_negocio,
    )
    from fase03.exportacion import exportar_dataset_final

    import os
    os.makedirs(args.out_dir, exist_ok=True)

    legacy = cargar_modulo_legacy(args.legacy_script)

    separador("CARGANDO rba_2000_users.csv REAL")
    df_2000 = pd.read_csv(args.rba_2000)
    usuarios_seleccionados = sorted(df_2000["User ID"].unique().tolist())
    print(f"  Filas: {len(df_2000):,}  |  Usuarios distintos: {len(usuarios_seleccionados):,}")

    # --- Pipeline LEGACY (monolítico) ---
    separador("EJECUTANDO PIPELINE LEGACY (monolítico v4)")
    config_legacy = legacy.configurar_entorno()
    config_legacy["IPINFO_PATH"] = args.ipinfo
    config_legacy["N_USUARIOS"] = len(usuarios_seleccionados)
    config_legacy["OUT_EMPLEADOS"] = os.path.join(args.out_dir, "empleados_legacy.csv")
    config_legacy["OUT_DATASET_FINAL"] = os.path.join(args.out_dir, "dataset_legacy.csv")

    df_emp_legacy = legacy.generar_empleados(usuarios_seleccionados, config_legacy)
    df_int_legacy = df_2000.merge(df_emp_legacy, on="User ID", how="inner")
    df_int_legacy, _ = legacy.resolver_ips(df_int_legacy, config_legacy)
    df_int_legacy, _ = legacy.crear_features_temporales(df_int_legacy, config_legacy)
    df_int_legacy, _ = legacy.crear_feature_impossible_travel(df_int_legacy, config_legacy)
    df_int_legacy = legacy.crear_feature_turnos(df_int_legacy)
    df_int_legacy = legacy.crear_features_negocio(df_int_legacy)
    df_final_legacy = legacy.exportar_dataset_final(df_int_legacy, config_legacy)

    # --- Pipeline MODULAR ---
    separador("EJECUTANDO PIPELINE MODULAR (fase03/)")
    config_modular = ConfiguracionPipeline(
        IPINFO_PATH=args.ipinfo,
        N_USUARIOS=len(usuarios_seleccionados),
        OUT_EMPLEADOS=os.path.join(args.out_dir, "empleados_modular.csv"),
        OUT_DATASET_FINAL=os.path.join(args.out_dir, "dataset_modular.csv"),
    )
    df_emp_modular = GeneradorEmpleados(config_modular).generar(usuarios_seleccionados)
    df_int_modular = df_2000.merge(df_emp_modular, on="User ID", how="inner")
    df_int_modular, _ = ResolutorIPinfo(config_modular).resolver(df_int_modular)
    serie_target = df_int_modular.pop("Is Account Takeover")
    df_int_modular, _ = crear_features_temporales(df_int_modular, config_modular)
    df_int_modular, _ = crear_feature_impossible_travel(df_int_modular, config_modular)
    df_int_modular = crear_feature_turnos(df_int_modular)
    df_int_modular = crear_features_negocio(df_int_modular)
    df_int_modular["Is Account Takeover"] = serie_target
    df_final_modular = exportar_dataset_final(df_int_modular, config_modular)

    # --- Comparaciones ---
    reporte = {}
    comparar_forma(df_final_legacy, df_final_modular, reporte)
    comparar_columnas(df_final_legacy, df_final_modular, reporte)
    comparar_dtypes(df_final_legacy, df_final_modular, reporte)
    comparar_valores_exactos(df_final_legacy, df_final_modular, reporte)
    comparar_nulos(df_final_legacy, df_final_modular, reporte)
    comparar_distribuciones(df_final_legacy, df_final_modular, reporte)
    comparar_target(df_final_legacy, df_final_modular, reporte)
    if args.empleados_existente:
        comparar_contra_empleados_existente(
            config_modular.OUT_EMPLEADOS, args.empleados_existente, reporte
        )

    # --- Veredicto final ---
    separador("REPORTE FINAL")
    claves_criticas = [
        "forma_identica", "columnas_identicas", "dtypes_identicos",
        "valores_identicos", "nulos_identicos", "distribuciones_identicas",
        "target_identico",
    ]
    equivalente = all(reporte.get(k) for k in claves_criticas)
    for k in claves_criticas:
        print(f"  {k}: {reporte.get(k)}")
    if "coincide_con_empleados_historico" in reporte and reporte["coincide_con_empleados_historico"] is not None:
        print(f"  coincide_con_empleados_historico: {reporte['coincide_con_empleados_historico']}")

    print()
    if equivalente:
        print("VEREDICTO: EQUIVALENTE — el refactor modular produce EXACTAMENTE el "
              "mismo dataset_final_modelo.csv que el pipeline monolítico v4, con "
              "los mismos datos reales.")
    else:
        print("VEREDICTO: NO EQUIVALENTE — hay al menos una diferencia real entre "
              "el monolito y el modular. Revisa el detalle impreso arriba antes de "
              "aprobar la Etapa 1 con datos reales.")

    print()
    print("Copia TODA esta salida de consola de vuelta a Claude para decidir si "
          "se aprueba el paso a la Etapa 2.")


if __name__ == "__main__":
    main()

```

### ARCHIVO: fase03_refactor\tests\conftest.py
```python
"""
conftest.py
===========
Fixtures compartidos para las 4 capas de prueba de regresión.

Capa A (equivalencia end-to-end) y Capa B (reproducibilidad de
empleados.csv contra el fixture real) requieren archivos que NO
existen en este entorno de desarrollo — viven únicamente en el Google
Colab de Javier: rba_2000_users.csv (54.742 filas, generado en la
corrida real) y el catálogo IPinfo (~230 MB).

Estas pruebas se marcan con skip automático si los archivos no están
presentes, indicando exactamente qué variable de entorno definir para
activarlas. Esto es intencional: no se puede demostrar equivalencia
end-to-end sin los datos reales, pero el resto de la suite (Capas C y
D, más un smoke test sintético) sí corre siempre y no depende de nada
externo.
"""
import os
import pytest


def ruta_fixture_rba_2000():
    """Ruta al rba_2000_users.csv real, si Javier lo copió a
    tests/fixtures/ o definió la variable de entorno FASE03_RBA_2000_PATH."""
    return os.environ.get(
        "FASE03_RBA_2000_PATH",
        os.path.join(os.path.dirname(__file__), "fixtures", "rba_2000_users.csv"),
    )


def ruta_fixture_ipinfo():
    """Ruta al catálogo IPinfo real (~230 MB), si Javier lo copió a
    tests/fixtures/ o definió FASE03_IPINFO_PATH."""
    return os.environ.get(
        "FASE03_IPINFO_PATH",
        os.path.join(os.path.dirname(__file__), "fixtures", "country_asn.csv"),
    )


requiere_fixture_real = pytest.mark.skipif(
    not (os.path.exists(ruta_fixture_rba_2000()) and os.path.exists(ruta_fixture_ipinfo())),
    reason=(
        "Requiere los archivos reales de Colab: copia rba_2000_users.csv y "
        "country_asn.csv a tests/fixtures/, o define las variables de entorno "
        "FASE03_RBA_2000_PATH y FASE03_IPINFO_PATH. Sin estos archivos, la "
        "equivalencia end-to-end contra el pipeline monolítico no puede "
        "demostrarse con datos reales — se omite en vez de fingir que pasó."
    ),
)

```

### ARCHIVO: fase03_refactor\tests\test_fase03.py
```python
"""
test_fase03.py
==============
Suite de regresión de la Etapa 1 (refactor arquitectónico sin cambios
metodológicos). Cuatro capas, según lo acordado:

  CAPA A — equivalencia end-to-end (modular vs. monolito v4) sobre
           datos REALES (rba_2000_users.csv + catálogo IPinfo).
           Requiere archivos que solo existen en el Colab de Javier;
           se omite automáticamente si no están presentes (ver
           conftest.py), en vez de fingir que pasó.
  CAPA B — reproducibilidad de empleados.csv (mismos seeds -> mismo
           resultado, y equivalencia contra el monolito cuando hay
           fixture real).
  CAPA C — casos límite sintéticos (ISO2, centroides, country_mismatch,
           has_previous_login, edge case de un solo grupo en el
           rolling, fix de dtype de merge_asof).
  CAPA D — prueba de no-leakage: barajar 'Is Account Takeover' no debe
           cambiar ninguna feature calculada.

Además: un smoke test end-to-end con datos 100% sintéticos (no
requiere ningún archivo externo), que prueba que PipelineFase03 corre
de principio a fin sin errores.

Cuando una comparación falla, se usa pd.testing.assert_frame_equal con
check_exact=True, que reporta explícitamente qué columna y qué valores
difieren — nunca un booleano mudo de .equals().
"""
import importlib.util
import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fase03.config import ConfiguracionPipeline
from fase03.muestreo import MuestreoAleatorioSimple
from fase03.empleados import GeneradorEmpleados
from fase03.ip_resolver import ResolutorIPinfo
from fase03.features import (
    calcular_rolling_retrospectivo,
    crear_features_temporales,
    crear_feature_impossible_travel,
    crear_feature_turnos,
    crear_features_negocio,
)
from fase03.pipeline import PipelineFase03

from .conftest import requiere_fixture_real, ruta_fixture_rba_2000, ruta_fixture_ipinfo


def _cargar_monolito_v4():
    """Carga tests/legacy/fase03_pipeline_v4.py como módulo importable,
    para comparar su salida contra la arquitectura modular."""
    ruta = os.path.join(os.path.dirname(__file__), "legacy", "fase03_pipeline_v4.py")
    spec = importlib.util.spec_from_file_location("fase03_pipeline_v4_legacy", ruta)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


# ============================================================================
# CAPA A — Equivalencia end-to-end contra el pipeline monolítico (datos reales)
# ============================================================================

@requiere_fixture_real
def test_capa_a_equivalencia_end_to_end_contra_monolito(tmp_path):
    """Corre el monolito v4 y la arquitectura modular a partir del
    MISMO rba_2000_users.csv real, con el mismo config, y compara el
    dataset_final_modelo.csv resultante columna por columna."""
    legacy = _cargar_monolito_v4()

    df_2000 = pd.read_csv(ruta_fixture_rba_2000())
    usuarios_seleccionados = sorted(df_2000["User ID"].unique().tolist())

    # --- Config legacy (dict) ---
    config_legacy = legacy.configurar_entorno()
    config_legacy["IPINFO_PATH"] = ruta_fixture_ipinfo()
    config_legacy["N_USUARIOS"] = len(usuarios_seleccionados)
    config_legacy["OUT_EMPLEADOS"] = str(tmp_path / "empleados_legacy.csv")
    config_legacy["OUT_DATASET_FINAL"] = str(tmp_path / "dataset_legacy.csv")

    df_emp_legacy = legacy.generar_empleados(usuarios_seleccionados, config_legacy)
    df_int_legacy = df_2000.merge(df_emp_legacy, on="User ID", how="inner")
    df_int_legacy, _ = legacy.resolver_ips(df_int_legacy, config_legacy)
    df_int_legacy, _ = legacy.crear_features_temporales(df_int_legacy, config_legacy)
    df_int_legacy, _ = legacy.crear_feature_impossible_travel(df_int_legacy, config_legacy)
    df_int_legacy = legacy.crear_feature_turnos(df_int_legacy)
    df_int_legacy = legacy.crear_features_negocio(df_int_legacy)
    df_final_legacy = legacy.exportar_dataset_final(df_int_legacy, config_legacy)

    # --- Config modular (dataclass) ---
    config_modular = ConfiguracionPipeline(
        IPINFO_PATH=ruta_fixture_ipinfo(),
        N_USUARIOS=len(usuarios_seleccionados),
        OUT_EMPLEADOS=str(tmp_path / "empleados_modular.csv"),
        OUT_DATASET_FINAL=str(tmp_path / "dataset_modular.csv"),
    )

    df_emp_modular = GeneradorEmpleados(config_modular).generar(usuarios_seleccionados)
    df_int_modular = df_2000.merge(df_emp_modular, on="User ID", how="inner")
    df_int_modular, _ = ResolutorIPinfo(config_modular).resolver(df_int_modular)
    serie_target = df_int_modular.pop("Is Account Takeover")
    df_int_modular, _ = crear_features_temporales(df_int_modular, config_modular)
    df_int_modular, _ = crear_feature_impossible_travel(df_int_modular, config_modular)
    df_int_modular = crear_feature_turnos(df_int_modular)
    df_int_modular = crear_features_negocio(df_int_modular)
    df_int_modular["Is Account Takeover"] = serie_target
    from fase03.exportacion import exportar_dataset_final
    df_final_modular = exportar_dataset_final(df_int_modular, config_modular)

    pd.testing.assert_frame_equal(
        df_final_legacy.reset_index(drop=True),
        df_final_modular.reset_index(drop=True),
        check_exact=True,
        check_dtype=True,
    )


# ============================================================================
# CAPA B — Reproducibilidad de empleados.csv
# ============================================================================

def test_capa_b_empleados_reproducible_mismos_seeds():
    """Mismos RANDOM_STATE/FAKER_SEED + mismos usuarios -> mismo
    empleados.csv, byte a byte (columna a columna)."""
    config = ConfiguracionPipeline(N_USUARIOS=10)
    usuarios = list(range(1, 11))

    config.OUT_EMPLEADOS = "/tmp/empleados_run1.csv"
    df1 = GeneradorEmpleados(config).generar(usuarios)

    config.OUT_EMPLEADOS = "/tmp/empleados_run2.csv"
    df2 = GeneradorEmpleados(config).generar(usuarios)

    pd.testing.assert_frame_equal(df1, df2, check_exact=True)


@requiere_fixture_real
def test_capa_b_empleados_equivalente_a_monolito(tmp_path):
    """empleados.csv generado por la clase modular debe ser idéntico
    al generado por generar_empleados() del monolito, con el mismo
    config y la misma lista de usuarios reales."""
    legacy = _cargar_monolito_v4()

    df_2000 = pd.read_csv(ruta_fixture_rba_2000())
    usuarios_seleccionados = sorted(df_2000["User ID"].unique().tolist())

    config_legacy = legacy.configurar_entorno()
    config_legacy["N_USUARIOS"] = len(usuarios_seleccionados)
    config_legacy["OUT_EMPLEADOS"] = str(tmp_path / "empleados_legacy.csv")
    df_emp_legacy = legacy.generar_empleados(usuarios_seleccionados, config_legacy)

    config_modular = ConfiguracionPipeline(
        N_USUARIOS=len(usuarios_seleccionados),
        OUT_EMPLEADOS=str(tmp_path / "empleados_modular.csv"),
    )
    df_emp_modular = GeneradorEmpleados(config_modular).generar(usuarios_seleccionados)

    pd.testing.assert_frame_equal(
        df_emp_legacy.reset_index(drop=True),
        df_emp_modular.reset_index(drop=True),
        check_exact=True,
    )


# ============================================================================
# CAPA C — Casos límite sintéticos
# ============================================================================

def test_capa_c_pais_residencia_es_iso2():
    config = ConfiguracionPipeline(N_USUARIOS=5, OUT_EMPLEADOS="/tmp/empleados_c1.csv")
    df_emp = GeneradorEmpleados(config).generar([1, 2, 3, 4, 5])
    assert set(df_emp["Pais_Residencia"].unique()).issubset(config.ISO2_RECONOCIDOS)


def test_capa_c_centroides_usan_iso2_no_nombres_espanol():
    from fase03.config import CENTROIDES_GEOGRAFICOS
    assert "CO" in CENTROIDES_GEOGRAFICOS
    assert "Colombia" not in CENTROIDES_GEOGRAFICOS


def test_capa_c_country_mismatch_iso2_vs_iso2_y_nan_cuando_falta_info():
    df = pd.DataFrame({
        "Pais_Residencia": ["CO", "ES", "MX", None],
        "ip_country_code": ["CO", "US", "MX", "US"],
        "Estado_Cuenta": ["Activo", "Activo", "Inactivo", "Activo"],
        "login_exitoso_normalizado": [True, True, True, True],
    })
    df = crear_features_negocio(df)
    assert df.loc[0, "country_mismatch"] == 0
    assert df.loc[1, "country_mismatch"] == 1
    assert df.loc[2, "country_mismatch"] == 0
    assert pd.isna(df.loc[3, "country_mismatch"])


def test_capa_c_has_previous_login_y_nan_forzado_en_impossible_travel():
    config = ConfiguracionPipeline()
    df = pd.DataFrame({
        "User ID": [1, 1, 1],
        "IP Address": ["1.1.1.1", "1.1.1.2", "1.1.1.3"],
        "Login Timestamp": [1580000000, 1580000900, 1580100000],
        "Login Successful": [True, False, True],
        "Country": ["CO", "CO", "US"],
    })
    df, _ = crear_features_temporales(df, config)
    assert df.loc[0, "has_previous_login"] == 0
    assert df.loc[1, "has_previous_login"] == 1
    assert df.loc[2, "has_previous_login"] == 1

    df, _ = crear_feature_impossible_travel(df, config)
    assert pd.isna(df.loc[0, "distance_previous_km"])
    assert pd.isna(df.loc[0, "required_speed_kmh"])
    # CO -> US SÍ debe resolver distancia (centroides ISO2 alineados con
    # el formato nativo de RBA "Country"; antes, con nombres en español,
    # este lookup fallaba silenciosamente).
    assert not pd.isna(df.loc[2, "distance_previous_km"])


def test_capa_c_rolling_retrospectivo_con_un_solo_usuario():
    """Edge case de pandas >= 3.0: groupby().apply() puede devolver un
    DataFrame en vez de una Series concatenada cuando hay un único
    grupo. calcular_rolling_retrospectivo() debe ser robusto a esto."""
    df = pd.DataFrame({
        "User ID": [1, 1, 1],
        "Login Timestamp": pd.to_datetime([1580000000, 1580000900, 1580100000], unit="s"),
        "is_failed": [0, 1, 0],
    })
    resultado = calcular_rolling_retrospectivo(df, "is_failed", "15min")
    assert isinstance(resultado, pd.Series)
    assert pd.isna(resultado.iloc[0])
    assert resultado.iloc[1] == 0.0


def test_capa_c_merge_asof_dtype_fix_reproduce_escenario_real():
    """Reproduce el escenario exacto que causó el MergeError original:
    RBA con IPv6 mezclada (fuerza float64 en ip_int) vs. catálogo
    IPinfo 100% IPv4 (nace int64 nativamente)."""
    config = ConfiguracionPipeline(IPINFO_PATH="/tmp/ipinfo_mini_capa_c.csv")

    df_logs = pd.DataFrame({
        "IP Address": ["8.8.8.8", "1.1.1.1", "2001:db8::1", "9.9.9.9"],
    })
    from fase03.ip_utils import clasificar_ip
    clasif = df_logs["IP Address"].apply(clasificar_ip)
    df_logs["ip_int"] = clasif.apply(lambda t: t[0])
    df_logs["ip_version"] = clasif.apply(lambda t: t[1])
    assert df_logs["ip_int"].dtype == np.float64  # confirma que se reprodujo el escenario

    df_ipinfo_mini = pd.DataFrame({
        "start_ip": ["1.0.0.0", "8.0.0.0", "9.0.0.0"],
        "end_ip": ["1.255.255.255", "8.255.255.255", "9.255.255.255"],
        "country": ["US", "US", "US"],
        "country_name": ["United States", "United States", "United States"],
        "asn": ["AS1", "AS2", "AS3"],
        "as_name": ["A", "B", "C"],
        "as_domain": ["a.com", "b.com", "c.com"],
    })
    df_ipinfo_mini.to_csv(config.IPINFO_PATH, index=False)

    # No debe lanzar MergeError.
    df_resultado, diagnostico = ResolutorIPinfo(config).resolver(df_logs)
    assert diagnostico["ipv4_unicas_resueltas"] == 3


# ============================================================================
# CAPA D — Prueba de no-leakage
# ============================================================================

def _df_integrado_sintetico(n_usuarios=3, eventos_por_usuario=5, seed=0):
    rng = np.random.default_rng(seed)
    filas = []
    paises = ["CO", "US", "ES"]
    for uid in range(1, n_usuarios + 1):
        base_ts = 1580000000
        for i in range(eventos_por_usuario):
            filas.append({
                "User ID": uid,
                "IP Address": f"1.1.1.{uid}",
                "Login Timestamp": base_ts + i * 1000,
                "Login Successful": bool(rng.integers(0, 2)),
                "Country": paises[uid % len(paises)],
                "Pais_Residencia": paises[(uid + 1) % len(paises)],
                "ip_country_code": paises[uid % len(paises)],
                "Estado_Cuenta": "Activo" if uid % 2 == 0 else "Inactivo",
                "Turno_Asignado": "Diurno",
            })
    return pd.DataFrame(filas)


def _construir_todas_las_features(df, config):
    df, _ = crear_features_temporales(df, config)
    df, _ = crear_feature_impossible_travel(df, config)
    df = crear_feature_turnos(df)
    df = crear_features_negocio(df)
    return df


def test_capa_d_no_leakage_barajar_target_no_cambia_ninguna_feature():
    """Construye el mismo DataFrame base dos veces, cambiando
    ÚNICAMENTE los valores de 'Is Account Takeover' (barajados
    aleatoriamente), y confirma que TODAS las columnas de features
    calculadas son idénticas entre ambas corridas."""
    config = ConfiguracionPipeline()
    rng = np.random.default_rng(1)

    base = _df_integrado_sintetico()
    target_a = rng.integers(0, 2, size=len(base)).astype(bool)
    target_b = rng.permutation(target_a)  # mismos valores, orden barajado

    df_a = base.copy()
    df_a["Is Account Takeover"] = target_a
    df_b = base.copy()
    df_b["Is Account Takeover"] = target_b

    # Barrera real del pipeline: se retira ANTES de construir features.
    df_a.pop("Is Account Takeover")
    df_b.pop("Is Account Takeover")

    df_a = _construir_todas_las_features(df_a, config)
    df_b = _construir_todas_las_features(df_b, config)

    columnas_features = [
        "failed_attempts_15min", "failed_attempts_1h", "has_previous_login",
        "distance_previous_km", "required_speed_kmh", "impossible_travel",
        "is_outside_shift", "country_mismatch", "inactive_account_success",
    ]
    pd.testing.assert_frame_equal(
        df_a[columnas_features].reset_index(drop=True),
        df_b[columnas_features].reset_index(drop=True),
        check_exact=True,
    )


def test_capa_d_features_py_no_menciona_is_account_takeover():
    """Garantía estructural adicional: el código fuente de features.py
    no debe contener ninguna referencia textual a 'Is Account
    Takeover'. Si alguien la agregara por descuido, este test la
    detecta sin necesidad de ejecutar nada."""
    ruta_features = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), "fase03", "features.py"
    )
    contenido = open(ruta_features, encoding="utf-8").read()
    assert "Is Account Takeover" not in contenido


# ============================================================================
# SMOKE TEST — pipeline completo con datos 100% sintéticos (sin
# depender de ningún archivo externo). No es una de las 4 capas
# acordadas, mide únicamente que el cableado (imports, orquestación,
# inyección de dependencia) funciona de principio a fin.
# ============================================================================

def _generar_rba_sintetico(ruta, n_usuarios=8, eventos_por_usuario=16, seed=7):
    rng = np.random.default_rng(seed)
    filas = []
    ts_base = 1_580_000_000
    for uid in range(1, n_usuarios + 1):
        for i in range(eventos_por_usuario):
            filas.append({
                "User ID": uid,
                "IP Address": f"8.8.8.{(uid * 3 + i) % 255}",
                "Login Timestamp": ts_base + i * 900 + uid * 10,
                "Login Successful": bool(rng.integers(0, 2)),
                "Device Type": "Desktop",
                "Is Attack IP": False,
                "Is Account Takeover": bool(i == 0 and uid == 1),
                "Country": "CO" if uid % 2 == 0 else "US",
                "Region": "N/A",
                "City": "N/A",
                "ASN": "AS1",
                "Round-Trip Time [ms]": 50,
            })
    pd.DataFrame(filas).to_csv(ruta, index=False)


def _generar_ipinfo_sintetico(ruta):
    df = pd.DataFrame({
        "start_ip": ["8.8.8.0"],
        "end_ip": ["8.8.8.255"],
        "country": ["US"],
        "country_name": ["United States"],
        "asn": ["AS15169"],
        "as_name": ["Google"],
        "as_domain": ["google.com"],
    })
    df.to_csv(ruta, index=False)


def test_smoke_pipeline_completo_end_to_end_sintetico(tmp_path):
    rba_path = tmp_path / "rba_mini.csv"
    ipinfo_path = tmp_path / "ipinfo_mini.csv"
    _generar_rba_sintetico(str(rba_path))
    _generar_ipinfo_sintetico(str(ipinfo_path))

    config = ConfiguracionPipeline(
        RBA_PATH=str(rba_path),
        IPINFO_PATH=str(ipinfo_path),
        OUT_RBA_2000=str(tmp_path / "rba_seleccionados.csv"),
        OUT_EMPLEADOS=str(tmp_path / "empleados.csv"),
        OUT_DATASET_FINAL=str(tmp_path / "dataset_final_modelo.csv"),
        N_USUARIOS=5,
        MIN_EVENTOS_USUARIO=10,
        CHUNKSIZE_PASADA_1=1000,
        CHUNKSIZE_PASADA_2=1000,
    )
    estrategia = MuestreoAleatorioSimple(config)
    pipeline = PipelineFase03(config, estrategia)

    df_final = pipeline.ejecutar()

    assert len(df_final) > 0
    assert df_final["User ID"].nunique() == 5
    assert "Is Account Takeover" in df_final.columns
    assert "has_previous_login" in df_final.columns
    assert "country_mismatch" in df_final.columns
    assert os.path.exists(config.OUT_DATASET_FINAL)

```

### ARCHIVO: fase03_refactor\tests\__init__.py
```python

```

