# Informe técnico del EDA — Detección de Account Takeover (CRISP-DM)

*Generado automáticamente el 2026-10-19 05:51. Proyecto académico y experimental; no evidencia de eficacia clínica ni de rendimiento en producción.*

## 1. Objetivo y alcance

Describir el dataset final (antes del sobremuestreo) y los datos preparados para modelado (train/test), documentar su calidad y limitaciones, y dejar preparada —sin ejecutarla— la comparación descriptiva con `RobustScaler`. No se entrena ningún modelo ni se modifica el pipeline.

## 2. Artefactos utilizados (solo lectura)

| nombre | bytes | sha256 |
| --- | --- | --- |
| dataset_final_modelo.csv | 16,341,667 | f2694a3045d73cf363fd9815364446a02328376de93bbe882642d662837ad87d |
| dataset_train_prepared.csv | 28,012,008 | 0c5a495223f18b146695eef3683013297970c2590a79bb6e6d5da553afbc98ee |
| dataset_test_prepared.csv | 3,265,392 | 1a210c31f4fcb8fe9e17ff42d2b8d273a1b44d4a7b0d2b8b22ced5efbb446795 |

## 3. Validaciones ejecutadas en esta corrida

Estados: OK/FALLA (ejecutada), COINCIDE/NO_COINCIDE (frente a cifras reportadas en Colab), INFO (medición), NO_EJECUTADA (no se pudo ejecutar; no cuenta como éxito).

| validación | estado | detalle |
| --- | --- | --- |
| Hashes frente a los calculados en Colab | NO_EJECUTADA | No se aportó RUTA_HASHES_ESPERADOS (JSON {nombre: sha256}). |
| Invariante: impossible_travel y has_previous_login en {0,1}, sin nulos | OK | ambas columnas deben ser binarias completas. Violaciones: 0 |
| Invariante: impossible_travel=1 implica velocidad > umbral, tiempo < ventana e historial | OK | umbral=800.0 km/h, ventana=12.0 h. Violaciones: 0 |
| Invariante: has_previous_login=0 implica distancia, velocidad, tiempo y fecha previa nulos | OK | el primer evento de cada usuario no puede tener métricas calculadas. Violaciones: 0 |
| Invariante: velocidad no nula implica distancia no nula | OK | la velocidad se calcula a partir de la distancia. Violaciones: 0 |
| Invariante: has_previous_login=1 equivale a previous_login_timestamp no nulo | OK | coherencia entre indicador y fecha previa. Violaciones: 0 |
| Info: ausencias de distancia frente a velocidad | INFO | distance_previous_km nulos=50,609; required_speed_kmh nulos=50,609; filas con distancia y sin velocidad=0 |
| Orden temporal por usuario | OK | Usuarios con eventos desordenados: 0 |
| Objetivo y User ID fuera de las listas de predictores | OK | Ninguna columna prohibida en las listas de predictores |
| Train y test: mismas columnas y mismo orden | OK | train=72 test=72 |
| train: sin valores ausentes | OK | Valores ausentes: 0 |
| train: objetivo en {0,1} | OK |  |
| train: sin User ID | OK | Sin User ID no es posible análisis por usuario en train/test |
| test: sin valores ausentes | OK | Valores ausentes: 0 |
| test: objetivo en {0,1} | OK |  |
| test: sin User ID | OK | Sin User ID no es posible análisis por usuario en train/test |
| Final: filas | COINCIDE | calculado=57420 / reportado en Colab=57420 |
| Final: columnas | COINCIDE | calculado=35 / reportado en Colab=35 |
| Final: negativos | COINCIDE | calculado=57375 / reportado en Colab=57375 |
| Final: positivos | COINCIDE | calculado=45 / reportado en Colab=45 |
| Final: usuarios únicos | COINCIDE | calculado=2000 / reportado en Colab=2000 |
| Final: usuarios con ATO | COINCIDE | calculado=44 / reportado en Colab=44 |
| Final: filas completas duplicadas | COINCIDE | calculado=0 / reportado en Colab=0 |
| Final: ausentes en distance_previous_km | COINCIDE | calculado=50609 / reportado en Colab=50609 |
| Final: ausentes en required_speed_kmh | COINCIDE | calculado=50609 / reportado en Colab=50609 |
| train: filas | COINCIDE | calculado=93046 / reportado en Colab=93046 |
| train: columnas | COINCIDE | calculado=72 / reportado en Colab=72 |
| train: negativos | COINCIDE | calculado=46523 / reportado en Colab=46523 |
| train: positivos | COINCIDE | calculado=46523 / reportado en Colab=46523 |
| train: valores ausentes | COINCIDE | calculado=0 / reportado en Colab=0 |
| train: filas completas duplicadas | COINCIDE | calculado=46760 / reportado en Colab=46760 |
| train: duplicados dentro de positivos | COINCIDE | calculado=46487 / reportado en Colab=46487 |
| train: patrones positivos distintos | COINCIDE | calculado=36 / reportado en Colab=36 |
| train: máxima repetición de un patrón positivo | COINCIDE | calculado=1390 / reportado en Colab=1390 |
| test: filas | COINCIDE | calculado=10861 / reportado en Colab=10861 |
| test: columnas | COINCIDE | calculado=72 / reportado en Colab=72 |
| test: negativos | COINCIDE | calculado=10852 / reportado en Colab=10852 |
| test: positivos | COINCIDE | calculado=9 / reportado en Colab=9 |
| test: valores ausentes | COINCIDE | calculado=0 / reportado en Colab=0 |
| test: filas completas duplicadas | COINCIDE | calculado=19 / reportado en Colab=19 |
| test: duplicados dentro de positivos | COINCIDE | calculado=0 / reportado en Colab=0 |
| Partición reproducida: usuarios compartidos entre train y test | OK | 0 usuarios compartidos en la partición reproducida (NO es una comprobación sobre los CSV exportados) |
| Partición reproducida: filas de test = filas de test exportado | COINCIDE | calculado=10861 / reportado en Colab=10861 |
| Partición reproducida: positivos de test = exportado | COINCIDE | calculado=9 / reportado en Colab=9 |
| Partición reproducida: negativos de test = exportado | COINCIDE | calculado=10852 / reportado en Colab=10852 |
| Partición reproducida: negativos de train = exportado | COINCIDE | calculado=46523 / reportado en Colab=46523 |
| Partición reproducida: positivos originales de train = patrones positivos distintos exportados | COINCIDE | calculado=36 / reportado en Colab=36 |
| Alcance de la partición reproducida | INFO | Reproducir los conteos esperados NO demuestra que los CSV exportados correspondan exactamente a esa partición (no conservan User ID). |
| Reproducibilidad por muestreo | INFO | No aplica: el EDA no muestrea observaciones. El único elemento aleatorio es el 'jitter' visual de D2/D5, fijado con RANDOM_STATE. |
| Figura d1_clases_eventos_y_usuarios.png | OK | dimensiones=1667x776, bytes=89,543. Inspección visual: PENDIENTE |
| Figura d2_eventos_por_usuario.png | OK | dimensiones=1142x807, bytes=132,160. Inspección visual: PENDIENTE |
| Figura d3_cobertura_movimiento_y_pais.png | OK | dimensiones=1967x846, bytes=110,657. Inspección visual: PENDIENTE |
| Figura d4_fallos_previos_por_clase.png | OK | dimensiones=1817x776, bytes=79,779. Inspección visual: PENDIENTE |
| Figura d5_colas_movimiento_evaluable.png | OK | dimensiones=2172x1175, bytes=161,217. Inspección visual: PENDIENTE |
| Figura d6_binarias_por_clase.png | OK | dimensiones=1991x1109, bytes=147,315. Inspección visual: PENDIENTE |
| Figura d8_correlacion_numericas.png | OK | dimensiones=1295x1119, bytes=175,358. Inspección visual: PENDIENTE |
| Figura d9_distribucion_temporal.png | OK | dimensiones=1967x776, bytes=110,981. Inspección visual: PENDIENTE |
| Figura m1_balance_clases_final_train_test.png | OK | dimensiones=1442x846, bytes=69,130. Inspección visual: PENDIENTE |
| Figura m2_repeticion_patrones_positivos_train.png | OK | dimensiones=1738x790, bytes=71,208. Inspección visual: PENDIENTE |
| Figura m3a_ecdf_numericas_train_neg_vs_test_neg.png | OK | dimensiones=2117x1142, bytes=167,876. Inspección visual: PENDIENTE |
| Figura m3b_binarias_train_neg_vs_test_neg.png | OK | dimensiones=1967x1404, bytes=139,890. Inspección visual: PENDIENTE |
| Fuente intacta: final | OK | sha256 inicio=f2694a3045d73cf3… fin=f2694a3045d73cf3… |
| Fuente intacta: train | OK | sha256 inicio=0c5a495223f18b14… fin=0c5a495223f18b14… |
| Fuente intacta: test | OK | sha256 inicio=1a210c31f4fcb8fe… fin=1a210c31f4fcb8fe… |

## 4. Inventario de figuras y cifras calculadas

La columna *cifras_calculadas* son valores obtenidos en esta corrida; la interpretación queda **PENDIENTE de revisión visual** y no se redacta automáticamente.

| id | archivos | pregunta | variables | subconjunto | cifras_calculadas | interpretacion |
| --- | --- | --- | --- | --- | --- | --- |
| D1 | d1_clases_eventos_y_usuarios.png | ¿Qué tamaño real tiene la clase positiva, en eventos y en usuarios? | Is Account Takeover, User ID | Dataset final (todos los eventos) | 45 eventos ATO y 57,375 no ATO; 44 usuarios con ATO de 2,000. | PENDIENTE de revisión visual |
| D2 | d2_eventos_por_usuario.png | ¿Pocos usuarios concentran los eventos? ¿Difiere el historial de usuarios con ATO? | User ID, Is Account Takeover | Dataset final, agrupado por usuario | usuarios sin ATO: n=1,956, mediana=20, IQR=[17, 28]; usuarios con >=1 ATO: n=44, mediana=28, IQR=[21, 42] | PENDIENTE de revisión visual |
| D3 | d3_cobertura_movimiento_y_pais.png | ¿Qué parte de los eventos permite evaluar el movimiento y cómo es 'Country' frente al diccionario de centroides? | has_previous_login, required_speed_kmh, impossible_travel, Country | Dataset final, por clase | movimiento evaluable en 6,811 de 57,420 eventos (11.9 %); 58 valores distintos de Country; 7,295 eventos con Country en el diccionario y 50,125 fuera; 0 nulos | PENDIENTE de revisión visual |
| D4 | d4_fallos_previos_por_clase.png | ¿Los eventos ATO tienen más intentos fallidos previos? | failed_attempts_15min, failed_attempts_1h, Is Account Takeover | Dataset final, por clase | failed_attempts_15min: ≥1 fallo previo en 7 de 45 eventos ATO y 5,907 de 57,375 no ATO; failed_attempts_1h: ≥1 fallo previo en 7 de 45 eventos ATO y 7,062 de 57,375 no ATO | PENDIENTE de revisión visual |
| D5 | d5_colas_movimiento_evaluable.png | ¿Hay colas extremas en distancia, velocidad y tiempo? | distance_previous_km, required_speed_kmh, time_since_previous_login_hours | Dataset final, solo filas con velocidad calculada | distancia: 8 valores distintos en 6,811 filas evaluables; 6,782 con distancia 0; required_speed_kmh: mediana=0, máx=1.75e+05; time_since_previous_login_hours: mediana=5.76, máx=8.76e+03 | PENDIENTE de revisión visual |
| D6 | d6_binarias_por_clase.png | ¿Qué binarias difieren por clase? (impossible_travel en tres estados) | impossible_travel, is_outside_shift, country_mismatch, inactive_account_success | Dataset final, por clase | viaje imposible detectado: 0 de 45 eventos ATO y 9 de 57,375 no ATO; is_outside_shift=1: 29 de 45 ATO; ausente: 0 ATO / 0 no ATO; country_mismatch=1: 35 de 45 ATO; ausente: 10 ATO / 12,284 no ATO; inactive_account_success=1: 3 de 45 ATO; ausente: 0 ATO / 0 no ATO | PENDIENTE de revisión visual |
| D7 | (solo tabla) | PENDIENTE de validación conceptual: relación cruzada de Is Attack IP con el objetivo (solo tabla). | Is Attack IP, Is Account Takeover | Dataset final | 0 de 45 eventos ATO con Is Attack IP=True; 2,412 eventos con Is Attack IP=True en total. PENDIENTE de validación conceptual: sin veredicto sobre validez como predictor ni sobre fuga. | PENDIENTE de revisión visual |
| D8 | d8_correlacion_numericas.png | ¿Hay redundancia lineal entre las numéricas? | las 5 numéricas (sin objetivo) | Dataset final, pares completos | r(failed_attempts_15min, failed_attempts_1h)=0.804; n mínimo por par=6,811 | PENDIENTE de revisión visual |
| D9 | d9_distribucion_temporal.png | ¿Cómo se distribuyen los eventos por hora (UTC) y mes? | Login Timestamp, Is Account Takeover | Dataset final | rango de fechas 2020-02-03 13:06:26.920000 a 2021-02-28 23:04:04.878000; 13 meses distintos | PENDIENTE de revisión visual |
| M1 | m1_balance_clases_final_train_test.png | ¿Cómo cambió el balance de clases tras el split y el remuestreo? | Is Account Takeover | Final, train preparado, test preparado | final 57,375/45; train 46,523/46,523; test 10,852/9 (negativos/positivos) | PENDIENTE de revisión visual |
| M2 | m2_repeticion_patrones_positivos_train.png | ¿Cuánto se repiten los patrones positivos en train? | todas las columnas de train | Train preparado, solo filas positivas | 36 patrones positivos distintos; máxima repetición 1,390; mediana 1296; duplicados en positivos 46,487, en negativos 273 | PENDIENTE de revisión visual |
| M3 | m3a_ecdf_numericas_train_neg_vs_test_neg.png; m3b_binarias_train_neg_vs_test_neg.png | ¿Se parece test a train en numéricas y binarias (con centinela -1)? | num__*, bin__* | Train y test preparados, solo filas negativas | negativos comparados: train n=46,523, test n=10,852 | PENDIENTE de revisión visual |

## 5. D7 — `Is Attack IP`

**Estado: PENDIENTE de validación conceptual.** No se concluye fuga de información ni validez como predictor.

*Qué afirma la documentación oficial* (ficha del dataset en Zenodo, DOI 10.5281/zenodo.6782156, https://zenodo.org/records/6782156):
- `Is Attack IP`: la dirección IP figuraba en un conjunto de datos de atacantes conocidos.
- `Is Account Takeover`: el equipo de respuesta a incidentes del servicio identificó el intento de login como toma de cuenta.
- Las IP, los identificadores de navegador, las marcas de tiempo y los RTT fueron generados aleatoriamente; los valores son plausibles pero artificiales.

*Qué NO se puede determinar con esa documentación:*
- Cuándo se compiló el conjunto de atacantes conocidos respecto a cada login ni si estaba disponible en el momento real de la predicción.
- Cómo se asignó la bandera a las IP sintéticas generadas.
- Si la coincidencia con atacantes conocidos intervino en la identificación de la toma de cuenta.

*Documentación que falta:* el detalle del proceso de síntesis (repositorio das-group/rba-dataset y artículo de Wiefling et al., ACM TOPS 2022, doi 10.1145/3546069).

*Tabla cruzada:* `tablas/d7_attack_ip_vs_objetivo.csv` (solo conteos).


## 6. Comparación con RobustScaler

No ejecutada (desactivada por defecto). Diseño y límites en `eda/comparacion_escalado.py`.

## 7. Limitaciones que se mantienen

- El dataset final es una muestra enriquecida de eventos ATO: su proporción de ATO no equivale a la prevalencia real.
- El RBA es un dataset sintetizado (valores plausibles pero artificiales); no debe usarse en sistemas productivos de detección de intrusiones, según su documentación. Los empleados, turnos y estados de cuenta del proyecto son aún más sintéticos.
- Train contiene positivos sobremuestreados; sus filas no deben interpretarse como ataques independientes.
- Los patrones positivos distintos de train no deben describirse como eventos originales independientes sin rastrear su procedencia.
- Test contiene muy pocos positivos: las conclusiones basadas en porcentajes de esa clase son muy sensibles a cada observación.
- La separación por usuario está documentada en el código, pero el solapamiento cero NO se verificó de forma independiente a partir de los CSV preparados, que no conservan User ID.
- Reproducir los conteos de la partición no demuestra que los CSV exportados correspondan exactamente a ella.
- Los valores atípicos se investigan, no se eliminan.
- Las correlaciones no demuestran causalidad ni, por sí solas, fuga de información.
- Una comprobación del código no es una medición de los datos reales.
- impossible_travel = 0 no demuestra ausencia de viaje imposible: puede ser un caso no evaluable.
- Las ausencias de distancia/velocidad con historial previo tienen causa NO determinada con las columnas disponibles (previous_country no se exporta y no se reconstruye).

## 8. Cómo reproducir

```bash
# Desde la carpeta que contiene eda/ y fase03/ (no ejecuta la Fase 3 ni lee el RBA)
python -m eda.main_eda \
    --final /ruta/dataset_final_modelo.csv \
    --train /ruta/dataset_train_prepared.csv \
    --test  /ruta/dataset_test_prepared.csv \
    --salida eda_salida \
    --fase03-path /ruta/a/fase03_refactor      # opcional (solo lectura)
```
Opcionales: `--hashes-esperados hashes.json` (JSON {nombre_archivo: sha256}),
`--activar-comparacion-escalado` (apagado por defecto).


## 9. Pendientes

- Inspección visual de cada figura y redacción de interpretaciones.
- Resolver la validación conceptual de D7.
- Determinar la causa de las ausencias de distancia/velocidad con historial (requeriría `previous_country` u otra información no exportada).
- Comprobación independiente del solapamiento cero entre train y test (requeriría conservar `User ID` en los artefactos de partición).
